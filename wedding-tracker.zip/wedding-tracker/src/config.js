// Placeholder for local file previews. `npm run build` overwrites this in dist/
// with the values from your environment variables (see .env.example).
window.APP_CONFIG = { SUPABASE_URL: "https://YOUR-PROJECT.supabase.co", SUPABASE_ANON_KEY: "YOUR-ANON-KEY" };
