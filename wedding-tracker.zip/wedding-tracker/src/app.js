/* Wedding tracker – plain JavaScript, no build step needed beyond writing config.js.
   Data lives in Supabase; every table is scoped to a wedding and protected by row-level security. */
"use strict";

const CFG = window.APP_CONFIG || {};
const app = document.getElementById("app");
const dlg = document.getElementById("dlg");
const dlgForm = document.getElementById("dlgForm");

if (!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY || CFG.SUPABASE_URL.includes("YOUR-PROJECT")) {
  app.innerHTML = `<div class="narrow card stack"><h2>Almost there</h2>
    <p>This app doesn't know which Supabase project to use yet.</p>
    <p class="small">On Vercel, add <b>SUPABASE_URL</b> and <b>SUPABASE_ANON_KEY</b> under Project → Settings → Environment Variables, then redeploy.
    Running locally? Copy <code>.env.example</code> to <code>.env</code>, fill it in, and run <code>npm run dev</code>.</p></div>`;
  throw new Error("Missing Supabase settings");
}

const sb = window.supabase.createClient(CFG.SUPABASE_URL, CFG.SUPABASE_ANON_KEY);
const STATUSES = ["Not started", "In progress", "Done"];
const ROLES = { owner: "Owner", planner: "Planner", member: "Committee member" };
const ACTION_SECTION = "Meeting action points";

const S = {
  session: null, email: "", isAppAdmin: false, weddings: [], W: null, me: null,
  committees: [], members: [], tasks: [], meetings: [], updates: [], lists: [], items: [],
};
const ui = { taskFilter: { committee: "", status: "open", q: "" }, listId: null };

/* ================= helpers ================= */
const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const nl = v => esc(v).replace(/\n/g, "<br>");
const money = n => "$" + Number(n || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const isoLocal = d => { const x = new Date(d); x.setMinutes(x.getMinutes() - x.getTimezoneOffset()); return x.toISOString().slice(0, 10); };
const todayISO = () => isoLocal(new Date());
const addDays = (iso, n) => { const d = new Date(iso + "T12:00:00"); d.setDate(d.getDate() + n); return isoLocal(d); };
const fmtDate = (iso, o = { weekday: "short", day: "numeric", month: "short" }) => iso ? new Date(iso + "T12:00:00").toLocaleDateString("en-GB", o) : "";
const fmtLong = iso => fmtDate(iso, { weekday: "long", day: "numeric", month: "long", year: "numeric" });
const fmtStamp = ts => new Date(ts).toLocaleString("en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
const cName = id => S.committees.find(c => c.id === id)?.name || "No committee";
const myName = () => S.me?.name || S.email;
const canManage = () => ["owner", "planner"].includes(S.me?.role);
const isOwner = () => S.me?.role === "owner";
const isLate = t => t.due_date && t.status !== "Done" && t.due_date < todayISO();
const statusCls = s => (s === "Done" ? "done" : s === "In progress" ? "prog" : "");
const plural = (n, w) => `${n} ${w}${n === 1 ? "" : "s"}`;
const clean = o => Object.fromEntries(Object.entries(o).map(([k, v]) => [k, typeof v === "string" && v.trim() === "" ? null : v]));
const numOrNull = v => (v === null || v === undefined || v === "" ? null : Number(v));
const store = {
  get: k => { try { return localStorage.getItem(k); } catch { return null; } },
  set: (k, v) => { try { localStorage.setItem(k, v); } catch { /* private mode */ } },
};

function toast(msg, err = false) {
  document.querySelectorAll(".toast").forEach(t => t.remove());
  const el = document.createElement("div");
  el.className = "toast" + (err ? " err" : "");
  el.setAttribute("role", err ? "alert" : "status");
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), err ? 6000 : 2400);
}
async function run(promise, okMsg) {
  const { data, error } = await promise;
  if (error) { toast(friendly(error), true); throw error; }
  if (okMsg) toast(okMsg);
  return data;
}
function friendly(error) {
  const m = error.message || String(error);
  if (/row-level security/i.test(m)) return "You don't have permission to do that. Ask the wedding's planner.";
  if (/duplicate key/i.test(m)) return "That already exists.";
  if (/Failed to fetch|NetworkError/i.test(m)) return "No connection. Check your internet and try again.";
  return m;
}
function opts(list, selected, { blank } = {}) {
  return (blank !== undefined ? `<option value="">${esc(blank)}</option>` : "") +
    list.map(o => {
      const v = typeof o === "object" ? o.value : o, l = typeof o === "object" ? o.label : o;
      return `<option value="${esc(v)}" ${String(v) === String(selected ?? "") ? "selected" : ""}>${esc(l)}</option>`;
    }).join("");
}
const committeeOpts = sel => opts(S.committees.map(c => ({ value: c.id, label: c.name })), sel, { blank: "No committee" });

/* One dialog for every form. Buttons carry value="save" | "cancel" | "delete" | anything else. */
function openDialog(html, onSubmit, afterOpen) {
  dlgForm.innerHTML = html;
  dlgForm.onsubmit = async e => {
    e.preventDefault();
    const btn = e.submitter;
    const action = btn?.value || "save";
    if (action === "cancel") return dlg.close();
    const fd = Object.fromEntries(new FormData(dlgForm));
    if (btn) btn.disabled = true;
    try { const keepOpen = await onSubmit(fd, action); if (!keepOpen) dlg.close(); }
    catch (_) { /* error already shown */ }
    finally { if (btn) btn.disabled = false; }
  };
  if (!dlg.open) dlg.showModal();
  afterOpen?.();
  dlgForm.querySelector("input:not([type=checkbox]),select,textarea")?.focus();
}
const actionsBar = ({ save = "Save", del = null }) =>
  `<div class="actions"><button class="btn" value="save">${esc(save)}</button>
   <button class="btn ghost" value="cancel" formnovalidate>Cancel</button>
   ${del ? `<button class="btn danger left" value="delete" formnovalidate>${esc(del)}</button>` : ""}</div>`;

/* ================= sign in ================= */
function renderSignIn(step = "email", email = "") {
  setChrome(false);
  app.innerHTML = `<div class="narrow card stack">
    <h2>Sign in</h2>
    ${step === "email" ? `
      <p class="muted small">Use the email address the planner added for you. We'll email you a sign-in code.</p>
      <form id="emailForm"><label for="em">Email</label>
        <input id="em" name="email" type="email" autocomplete="email" required value="${esc(email)}">
        <div class="actions"><button class="btn">Email me a code</button></div></form>`
    : `
      <p class="muted small">We sent a code to <b>${esc(email)}</b>. Type it below, or tap the link in the email on this device.</p>
      <form id="codeForm"><label for="code">Sign-in code</label>
        <input id="code" name="code" inputmode="numeric" autocomplete="one-time-code" required>
        <div class="actions"><button class="btn">Sign in</button><button type="button" class="btn ghost left" id="back">Use another email</button></div></form>`}
  </div>`;
  if (step === "email") {
    document.getElementById("emailForm").onsubmit = async e => {
      e.preventDefault();
      const em = e.target.email.value.trim().toLowerCase();
      e.submitter.disabled = true;
      const { error } = await sb.auth.signInWithOtp({ email: em, options: { emailRedirectTo: location.origin + "/" } });
      e.submitter.disabled = false;
      if (error) return toast(/rate limit/i.test(error.message) ? "Too many sign-in emails just now. Wait a few minutes and try again." : error.message, true);
      renderSignIn("code", em);
    };
  } else {
    document.getElementById("back").onclick = () => renderSignIn("email", email);
    document.getElementById("codeForm").onsubmit = async e => {
      e.preventDefault();
      e.submitter.disabled = true;
      const { error } = await sb.auth.verifyOtp({ email, token: e.target.code.value.trim(), type: "email" });
      e.submitter.disabled = false;
      if (error) toast("That code didn't work. Check it, or go back and request a new one.", true);
    };
  }
}
document.getElementById("signOut").onclick = () => sb.auth.signOut();
document.getElementById("switchWedding").onclick = () => switchWeddingDialog();

function setChrome(on) {
  document.getElementById("tabs").hidden = !on;
  document.getElementById("who").hidden = !S.session;
  if (!on) {
    document.getElementById("couple").textContent = "Wedding tracker";
    document.getElementById("weddingSub").textContent = "";
    document.getElementById("countWrap").hidden = true;
  }
}

/* ================= boot ================= */
async function boot(session) {
  S.session = session;
  if (!session) return renderSignIn();
  S.email = session.user.email.toLowerCase();
  app.innerHTML = `<p class="muted">Loading…</p>`;
  const [w, a] = await Promise.all([
    sb.from("weddings").select("*").order("wedding_date", { ascending: true }),
    sb.from("app_admins").select("email").eq("email", S.email),
  ]);
  if (w.error) { app.innerHTML = `<div class="narrow card"><h2>Couldn't load</h2><p>${esc(friendly(w.error))}</p></div>`; return; }
  S.weddings = w.data;
  S.isAppAdmin = !a.error && a.data.length > 0;
  document.getElementById("whoName").textContent = `Signed in as ${S.email}`;
  document.getElementById("switchWedding").hidden = !(S.weddings.length > 1 || S.isAppAdmin);
  setChrome(false);
  document.getElementById("who").hidden = false;

  if (!S.weddings.length) {
    if (S.isAppAdmin) return createWeddingScreen();
    app.innerHTML = `<div class="narrow card stack"><h2>You're not on a wedding team yet</h2>
      <p class="muted">${esc(S.email)} hasn't been added to any wedding. Ask the planner to add this email on their Team page, then refresh.</p></div>`;
    return;
  }
  const saved = store.get("weddingId");
  const today = todayISO();
  const pick = S.weddings.find(x => x.id === saved)
    || S.weddings.find(x => x.status === "active" && x.wedding_date >= today)
    || S.weddings.find(x => x.status === "active") || S.weddings[0];
  await openWedding(pick.id);
}

async function openWedding(id) {
  if (S.W?.id !== id) { ui.taskFilter = { committee: "", status: "open", q: "" }; ui.listId = null; }
  S.W = S.weddings.find(x => x.id === id);
  store.set("weddingId", id);
  if (!(await loadWedding())) return;
  renderHeader();
  setChrome(true);
  route();
}

async function loadWedding() {
  const id = S.W.id;
  const q = (t, col, asc = true) => sb.from(t).select("*").eq("wedding_id", id).order(col, { ascending: asc });
  const res = await Promise.all([
    q("committees", "sort"), q("wedding_members", "name"), q("tasks", "sort"), q("meetings", "meeting_date"),
    q("updates", "created_at", false), q("budget_lists", "sort"), q("budget_items", "sort"),
    sb.from("weddings").select("*").eq("id", id).single(),
  ]);
  const bad = res.find(r => r.error);
  if (bad) { toast(friendly(bad.error), true); return false; }
  [S.committees, S.members, S.tasks, S.meetings, S.updates, S.lists, S.items] = res.slice(0, 7).map(r => r.data);
  S.W = res[7].data;
  S.weddings = S.weddings.map(x => (x.id === id ? S.W : x));
  S.me = S.members.find(m => m.email === S.email) || null;
  return true;
}
const reload = async () => { await loadWedding(); renderHeader(); route(); };

function renderHeader() {
  const W = S.W;
  document.title = `${W.couple} · Wedding tracker`;
  document.getElementById("couple").textContent = W.couple;
  document.getElementById("weddingSub").textContent = [fmtLong(W.wedding_date), W.venue].filter(Boolean).join(" · ") + (W.status === "archived" ? " · Archived" : "");
  const days = Math.round((new Date(W.wedding_date + "T12:00:00") - new Date(todayISO() + "T12:00:00")) / 864e5);
  document.getElementById("countWrap").hidden = false;
  document.getElementById("days").textContent = days > 0 ? days : days === 0 ? "Today" : "✓";
  document.getElementById("daysLabel").textContent = days > 1 ? "days to go" : days === 1 ? "day to go" : days === 0 ? "" : "married";
  document.getElementById("whoName").textContent = `${myName()}${S.me ? " · " + ROLES[S.me.role] : ""}`;
}

let lastUser;
sb.auth.onAuthStateChange((_event, session) => {
  const uid = session?.user?.id ?? null;
  S.session = session;
  if (uid === lastUser) return;
  lastUser = uid;
  setTimeout(() => boot(session), 0);
});
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible" && S.W && !dlg.open) reload();
});

/* ================= routing ================= */
window.addEventListener("hashchange", () => { if (dlg.open) dlg.close(); route(); });
function route() {
  if (!S.W) return;
  const h = location.hash.slice(1) || "today";
  const tab = h.split("-")[0];
  document.querySelectorAll("nav.tabs a").forEach(a =>
    a.getAttribute("href") === "#" + tab ? a.setAttribute("aria-current", "page") : a.removeAttribute("aria-current"));
  if (h.startsWith("meeting-")) return viewMeeting(Number(h.slice(8)));
  if (h.startsWith("budget-")) { ui.listId = Number(h.slice(7)); return viewBudget(); }
  ({ today: viewToday, checklist: viewChecklist, meetings: viewMeetings, budget: viewBudget, team: viewTeam }[tab] || viewToday)();
}
const go = hash => { if (location.hash === hash) route(); else location.hash = hash; };

/* ================= meetings: shared logic ================= */
const meetingsAsc = () => [...S.meetings].sort((a, b) => a.meeting_date.localeCompare(b.meeting_date) || a.id - b.id);
const isBefore = (a, b) => a.meeting_date < b.meeting_date || (a.meeting_date === b.meeting_date && a.id < b.id);
const prevMeeting = m => meetingsAsc().filter(x => isBefore(x, m)).pop();
const nextMeeting = m => meetingsAsc().find(x => isBefore(m, x));
const actionsOf = m => S.tasks.filter(t => t.source_meeting_id === m.id).sort((a, b) => (a.due_date || "9").localeCompare(b.due_date || "9"));
const minutesOutstanding = m => m.meeting_date < todayISO() && !m.minutes_final;
function mattersArising(m) {
  const earlier = new Set(S.meetings.filter(x => isBefore(x, m)).map(x => x.id));
  const fromEarlier = S.tasks.filter(t => earlier.has(t.source_meeting_id));
  const prev = prevMeeting(m);
  return {
    open: fromEarlier.filter(t => t.status !== "Done"),
    closed: fromEarlier.filter(t => t.status === "Done" && (!prev || t.updated_at.slice(0, 10) >= prev.meeting_date)),
  };
}
const meetingTitle = m => `${fmtDate(m.meeting_date, { weekday: "long", day: "numeric", month: "long" })}${m.start_time ? ", " + m.start_time : ""}`;

/* ================= Today ================= */
function viewToday() {
  const total = S.tasks.length, done = S.tasks.filter(t => t.status === "Done").length;
  const late = S.tasks.filter(isLate).sort((a, b) => a.due_date.localeCompare(b.due_date));
  const t0 = todayISO(), wk = addDays(t0, 7);
  const next = meetingsAsc().find(m => m.meeting_date >= t0);
  const soon = S.tasks.filter(t => t.status !== "Done" && t.due_date && t.due_date >= t0 && t.due_date <= wk).sort((a, b) => a.due_date.localeCompare(b.due_date));
  const owed = S.meetings.filter(minutesOutstanding).sort((a, b) => b.meeting_date.localeCompare(a.meeting_date));
  const openActions = S.tasks.filter(t => t.source_meeting_id && t.status !== "Done").length;
  const bTotal = S.items.reduce((s, f) => s + Number(f.amount), 0), bBought = S.items.filter(f => f.bought).reduce((s, f) => s + Number(f.amount), 0);
  app.innerHTML = `
  ${S.W.status === "archived" ? `<div class="card alert small" style="margin-bottom:12px">This wedding is archived. You can still view and edit it.</div>` : ""}
  ${owed.length ? `<div class="card alert stack" style="margin-bottom:12px"><div><b>Minutes outstanding</b></div>
     ${owed.map(m => `<div class="spread small"><span>${esc(meetingTitle(m))}${m.minutes_taker ? ` · taken by ${esc(m.minutes_taker)}` : ""}</span><a href="#meeting-${m.id}">Finish minutes</a></div>`).join("")}</div>` : ""}
  <div class="grid2">
    <div class="card stat"><div class="muted small">Checklist</div><div class="n">${done} of ${total} done</div>
      <div class="bar"><i style="width:${total ? Math.round(done / total * 100) : 0}%"></i></div>
      <div class="small muted" style="margin-top:6px">${plural(openActions, "open action point")} from meetings</div></div>
    <div class="card stat"><div class="muted small">Next meeting</div>
      ${next ? `<div class="n">${esc(fmtDate(next.meeting_date))}</div><div class="small">${esc([next.start_time, next.place].filter(Boolean).join(", "))}</div><a class="small" href="#meeting-${next.id}">Open meeting</a>`
             : `<div class="small" style="margin-top:6px">No meeting booked.</div><button class="linkish" id="bookMtg">Book the next meeting</button>`}</div>
    <div class="card stat"><div class="muted small">Budget lists</div><div class="n">${money(bTotal)}</div>
      <div class="small muted">${money(bBought)} bought or paid so far</div></div>
  </div>
  <h3>Overdue (${late.length})</h3>
  ${late.length ? late.map(taskRow).join("") : `<p class="muted small">Nothing overdue.</p>`}
  <h3>Due in the next 7 days (${soon.length})</h3>
  ${soon.length ? soon.map(taskRow).join("") : `<p class="muted small">Nothing else due this week.</p>`}
  <h3>Latest committee updates</h3>
  <div class="card">${S.updates.length ? S.updates.slice(0, 6).map(u => updateBlock(u, true)).join("") : `<p class="muted small" style="margin:0">No updates yet. Committees report inside a meeting.</p>`}</div>`;
  bindTaskRows();
  document.getElementById("bookMtg")?.addEventListener("click", () => editMeeting(null));
}

/* ================= Checklist ================= */
function taskRow(t) {
  const src = t.source_meeting_id && S.meetings.find(m => m.id === t.source_meeting_id);
  return `<button type="button" class="task ${t.status === "Done" ? "is-done" : ""}" data-task="${t.id}">
    <span class="dot ${statusCls(t.status)}" aria-hidden="true"></span>
    <span class="t">${esc(t.title)}</span>
    <span class="meta"><span class="pill ${statusCls(t.status)}">${esc(t.status)}</span>
      ${t.due_date ? `<span class="${isLate(t) ? "late" : ""}">${isLate(t) ? "Overdue · " : "Due "}${esc(fmtDate(t.due_date))}</span>` : ""}
      <span>${esc(cName(t.committee_id))}</span>${t.responsible ? `<span>👤 ${esc(t.responsible)}</span>` : ""}
      ${src ? `<span>From meeting ${esc(fmtDate(src.meeting_date))}</span>` : ""}</span>
    ${t.notes ? `<span class="note">${esc(t.notes)}</span>` : ""}
  </button>`;
}
function bindTaskRows() { app.querySelectorAll("[data-task]").forEach(b => (b.onclick = () => editTask(Number(b.dataset.task)))); }

function sectionsInOrder(list) {
  const first = {};
  for (const t of list) {
    const s = t.section || "Other", d = t.due_date || "9999";
    if (!(s in first) || d < first[s]) first[s] = d;
  }
  return Object.keys(first).sort((a, b) => first[a].localeCompare(first[b]));
}

function viewChecklist() {
  const f = ui.taskFilter;
  const list = S.tasks.filter(t =>
    (!f.committee || String(t.committee_id) === f.committee) &&
    (f.status === "" || (f.status === "open" ? t.status !== "Done" : f.status === "late" ? isLate(t) : f.status === "actions" ? !!t.source_meeting_id : t.status === f.status)) &&
    (!f.q || `${t.title} ${t.notes || ""} ${t.responsible || ""}`.toLowerCase().includes(f.q.toLowerCase())));
  const sortT = (a, b) => (a.due_date || "9999").localeCompare(b.due_date || "9999") || a.sort - b.sort;
  app.innerHTML = `
  <div class="spread"><h2>Checklist</h2><button class="btn" id="addTask">Add task</button></div>
  <div class="filters">
    <select id="fc" aria-label="Committee">${opts(S.committees.map(c => ({ value: c.id, label: c.name })), f.committee, { blank: "All committees" })}</select>
    <select id="fs" aria-label="Show">${opts([{ value: "open", label: "Still to do" }, { value: "late", label: "Overdue" }, { value: "actions", label: "Meeting action points" },
      ...STATUSES.map(s => ({ value: s, label: s })), { value: "", label: "Everything" }], f.status)}</select>
    <input id="fq" type="search" placeholder="Search tasks, notes or names" value="${esc(f.q)}" aria-label="Search">
  </div>
  <p class="small muted">${plural(list.length, "task")} shown</p>
  ${sectionsInOrder(list).map(sec => `<h3>${esc(sec)}</h3>${list.filter(t => (t.section || "Other") === sec).sort(sortT).map(taskRow).join("")}`).join("")
    || `<div class="empty">No tasks match these filters.</div>`}`;
  bindTaskRows();
  document.getElementById("fc").onchange = e => { f.committee = e.target.value; viewChecklist(); };
  document.getElementById("fs").onchange = e => { f.status = e.target.value; viewChecklist(); };
  const fq = document.getElementById("fq");
  fq.oninput = e => {
    f.q = e.target.value; clearTimeout(fq._t);
    fq._t = setTimeout(() => { viewChecklist(); const n = document.getElementById("fq"); n.focus(); n.setSelectionRange(n.value.length, n.value.length); }, 250);
  };
  document.getElementById("addTask").onclick = () => editTask(null);
}

function editTask(id, preset = {}) {
  const t = S.tasks.find(x => x.id === id) || { status: "Not started", ...preset };
  const history = id ? S.updates.filter(u => u.task_id === id) : [];
  const sections = [...new Set([...sectionsInOrder(S.tasks), t.section].filter(Boolean))];
  const src = t.source_meeting_id && S.meetings.find(m => m.id === t.source_meeting_id);
  openDialog(`
    <h2>${id ? "Edit task" : t.source_meeting_id ? "New action point" : "New task"}</h2>
    ${src ? `<p class="small muted" style="margin-top:-6px">Action point from the meeting on <a href="#meeting-${src.id}">${esc(fmtDate(src.meeting_date))}</a></p>` : ""}
    <label for="tt">${t.source_meeting_id ? "What needs to be done" : "Task"}</label><input id="tt" name="title" required value="${esc(t.title)}">
    <div class="grid2">
      <div><label for="tr">Person responsible</label><input id="tr" name="responsible" value="${esc(t.responsible)}"></div>
      <div><label for="td">Due date</label><input id="td" name="due_date" type="date" value="${esc(t.due_date)}"></div>
      <div><label for="tc">Committee</label><select id="tc" name="committee_id">${committeeOpts(t.committee_id)}</select></div>
      <div><label for="ts">Status</label><select id="ts" name="status">${opts(STATUSES, t.status)}</select></div>
    </div>
    <label for="tsec">Checklist heading</label><input id="tsec" name="section" list="secList" value="${esc(t.section)}" placeholder="e.g. One month before">
    <datalist id="secList">${sections.map(s => `<option value="${esc(s)}">`).join("")}</datalist>
    <label for="tn">Notes</label><textarea id="tn" name="notes">${esc(t.notes)}</textarea>
    ${t.updated_by ? `<p class="hint">Last changed by ${esc(t.updated_by)}, ${esc(fmtStamp(t.updated_at))}</p>` : ""}
    ${history.length ? `<h3>Updates on this task</h3>${history.map(u => updateBlock(u, true)).join("")}` : ""}
    ${actionsBar({ save: t.source_meeting_id && !id ? "Add action point" : "Save task", del: id ? "Delete" : null })}`,
    async (fd, action) => {
      if (action === "delete") {
        if (!confirm("Delete this task? This can't be undone.")) throw new Error("cancelled");
        await run(sb.from("tasks").delete().eq("id", id), "Task deleted");
      } else {
        const row = clean({ ...fd, updated_at: new Date().toISOString(), updated_by: myName() });
        row.committee_id = numOrNull(row.committee_id);
        if (id) await run(sb.from("tasks").update(row).eq("id", id), "Task saved");
        else await run(sb.from("tasks").insert({
          ...row, wedding_id: S.W.id, source_meeting_id: t.source_meeting_id || null,
          sort: Math.max(0, ...S.tasks.map(x => x.sort)) + 1,
        }), t.source_meeting_id ? "Action point added to the checklist" : "Task added");
      }
      await reload();
    });
}

/* ================= Meetings list ================= */
function minutesPill(m) {
  if (m.meeting_date > todayISO()) return `<span class="pill">Upcoming</span>`;
  if (m.meeting_date === todayISO() && !m.minutes_final) return `<span class="pill prog">Today</span>`;
  return m.minutes_final ? `<span class="pill done">Minutes final</span>` : `<span class="pill warn">Minutes outstanding</span>`;
}
function viewMeetings() {
  const t0 = todayISO();
  const upcoming = meetingsAsc().filter(m => m.meeting_date >= t0);
  const past = meetingsAsc().filter(m => m.meeting_date < t0).reverse();
  const tile = m => {
    const n = S.updates.filter(u => u.meeting_id === m.id).length, a = actionsOf(m).length;
    return `<a class="mtg" href="#meeting-${m.id}"><div class="card row" style="flex-wrap:nowrap">
      <div class="date-tile"><b>${new Date(m.meeting_date + "T12:00:00").getDate()}</b><span>${esc(fmtDate(m.meeting_date, { month: "short" }))}</span></div>
      <div style="flex:1"><div class="spread"><span style="font-weight:600">${esc(meetingTitle(m))}</span>${minutesPill(m)}</div>
      <div class="small muted">${esc(m.place || "Place not set")} · ${plural(n, "update")} · ${plural(a, "action point")}</div></div></div></a>`;
  };
  app.innerHTML = `
  <div class="spread"><h2>Meetings</h2><button class="btn" id="addMtg">New meeting</button></div>
  <p class="small muted">Each meeting keeps its own minutes: attendance, matters arising, committee updates, decisions and action points. Share them on WhatsApp or print them when they're done.</p>
  <h3>Coming up</h3><div class="stack">${upcoming.map(tile).join("") || `<p class="muted small">No meetings booked.</p>`}</div>
  <h3>Past meetings</h3><div class="stack">${past.map(tile).join("") || `<p class="muted small">None yet.</p>`}</div>`;
  document.getElementById("addMtg").onclick = () => editMeeting(null);
}

function editMeeting(id) {
  const last = meetingsAsc().pop();
  const m = S.meetings.find(x => x.id === id) || {
    meeting_date: last && last.meeting_date >= todayISO() ? addDays(last.meeting_date, 7) : todayISO(),
    start_time: last?.start_time, place: last?.place, chair: last?.chair,
  };
  openDialog(`
    <h2>${id ? "Edit meeting details" : "New meeting"}</h2>
    <div class="grid2">
      <div><label for="md">Date</label><input id="md" name="meeting_date" type="date" required value="${esc(m.meeting_date)}"></div>
      <div><label for="mt">Time</label><input id="mt" name="start_time" placeholder="e.g. 6:30pm" value="${esc(m.start_time)}"></div>
    </div>
    <label for="mp">Where</label><input id="mp" name="place" placeholder="Church hall, WhatsApp call, Google Meet link…" value="${esc(m.place)}">
    <div class="grid2">
      <div><label for="mc">Chair</label><input id="mc" name="chair" value="${esc(m.chair)}"></div>
      <div><label for="mk">Minutes taken by</label><input id="mk" name="minutes_taker" value="${esc(m.minutes_taker)}"></div>
    </div>
    <label for="ma">Present</label><textarea id="ma" name="attendees" style="min-height:60px" placeholder="Names, separated by commas">${esc(m.attendees)}</textarea>
    <label for="mo">Apologies</label><input id="mo" name="apologies" value="${esc(m.apologies)}">
    <label for="mm">Decisions and other minutes</label><textarea id="mm" name="minutes" style="min-height:120px">${esc(m.minutes)}</textarea>
    ${actionsBar({ save: id ? "Save details" : "Create meeting", del: id && canManage() ? "Delete meeting" : null })}`,
    async (fd, action) => {
      if (action === "delete") {
        if (!confirm("Delete this meeting and all its committee updates? Its action points stay on the checklist.")) throw new Error("cancelled");
        await run(sb.from("meetings").delete().eq("id", id), "Meeting deleted");
        await loadWedding(); go("#meetings");
      } else if (id) {
        await run(sb.from("meetings").update({ ...clean(fd), updated_at: new Date().toISOString() }).eq("id", id), "Meeting saved");
        await reload();
      } else {
        const rows = await run(sb.from("meetings").insert({ ...clean(fd), wedding_id: S.W.id, created_by: myName() }).select(), "Meeting created");
        await loadWedding(); go("#meeting-" + rows[0].id);
      }
    });
}

/* ================= One meeting (the minutes) ================= */
function updateBlock(u, showMeeting = false) {
  const task = S.tasks.find(t => t.id === u.task_id);
  const m = S.meetings.find(x => x.id === u.meeting_id);
  return `<div class="upd">
    <div class="h"><b style="color:var(--wine)">${esc(cName(u.committee_id))}</b> · ${esc(u.author || "")} · ${esc(fmtStamp(u.created_at))}
      ${showMeeting && m ? ` · <a href="#meeting-${m.id}">meeting ${esc(fmtDate(m.meeting_date))}</a>` : ""}</div>
    ${task ? `<div class="small">Task: ${esc(task.title)}${u.new_status ? ` → <span class="pill ${statusCls(u.new_status)}">${esc(u.new_status)}</span>` : ""}</div>` : ""}
    <p><span class="lbl">Done:</span> ${nl(u.done)}</p>
    ${u.next_steps ? `<p><span class="lbl">Next:</span> ${nl(u.next_steps)}</p>` : ""}
    ${u.blockers ? `<p><span class="lbl" style="color:var(--danger)">Needs help with:</span> ${nl(u.blockers)}</p>` : ""}
  </div>`;
}
function apRow(t, withMeeting = false) {
  const src = withMeeting && S.meetings.find(m => m.id === t.source_meeting_id);
  return `<div class="ap">
    <div><button type="button" class="linkish" style="font-size:14.5px;font-weight:600;text-decoration:none;color:var(--ink);text-align:left" data-task="${t.id}">${esc(t.title)}</button>
      <div class="meta">${esc(t.responsible || "No owner")} · ${esc(cName(t.committee_id))}${t.due_date ? ` · <span class="${isLate(t) ? "late" : ""}">due ${esc(fmtDate(t.due_date))}</span>` : ""}${src ? ` · raised ${esc(fmtDate(src.meeting_date))}` : ""}</div></div>
    <select data-status="${t.id}" aria-label="Status of ${esc(t.title)}">${opts(STATUSES, t.status)}</select>
  </div>`;
}

function viewMeeting(id) {
  const m = S.meetings.find(x => x.id === id);
  if (!m) { app.innerHTML = `<div class="empty">This meeting no longer exists. <a href="#meetings">Back to meetings</a></div>`; return; }
  const ups = S.updates.filter(u => u.meeting_id === id).sort((a, b) => a.created_at.localeCompare(b.created_at));
  const reported = new Set(ups.map(u => u.committee_id));
  const waiting = S.committees.filter(c => !reported.has(c.id));
  const ma = mattersArising(m);
  const acts = actionsOf(m);
  const prev = prevMeeting(m);
  app.innerHTML = `
  <p class="small"><a href="#meetings">All meetings</a></p>
  <div class="spread"><h2 style="margin-bottom:4px">${esc(meetingTitle(m))}</h2>${minutesPill(m)}</div>
  <div class="row" style="margin:10px 0 14px">
    <button class="btn" id="share">Share minutes</button>
    <button class="btn ghost" id="editMtg">Edit details</button>
    ${m.meeting_date > todayISO() ? "" : m.minutes_final ? `<button class="btn ghost" id="finalise" data-v="0">Reopen minutes</button>` : `<button class="btn gold" id="finalise" data-v="1">Mark minutes final</button>`}
  </div>

  <div class="card minutes-head">
    <div><div class="k">Where</div>${esc(m.place || "Not set")}</div>
    <div><div class="k">Chair</div>${esc(m.chair || "Not set")}</div>
    <div><div class="k">Minutes taken by</div>${esc(m.minutes_taker || "Not set")}</div>
    <div><div class="k">Present</div>${nl(m.attendees || "Not recorded")}</div>
    ${m.apologies ? `<div><div class="k">Apologies</div>${nl(m.apologies)}</div>` : ""}
  </div>

  <h3>Matters arising ${prev ? `<span class="small muted" style="font-weight:500">from earlier meetings</span>` : ""}</h3>
  <div class="card">
    ${ma.open.length ? ma.open.map(t => apRow(t, true)).join("") : `<p class="small muted" style="margin:0">${prev ? "No open action points from earlier meetings." : "This is the first meeting, so there's nothing carried over."}</p>`}
    ${ma.closed.length ? `<p class="small" style="margin:12px 0 0;color:var(--ok)">Done since the last meeting: ${ma.closed.map(t => esc(t.title)).join("; ")}</p>` : ""}
  </div>

  <div class="spread" style="margin-top:24px"><h3 style="margin:0">Committee updates (${ups.length})</h3><button class="btn" id="addUpd">Add update</button></div>
  ${waiting.length ? `<p class="small muted" style="margin:8px 0 6px">Still to report (tap to add their update):</p><div class="chips">${waiting.map(c => `<button type="button" class="chip" data-c="${c.id}">${esc(c.name)}</button>`).join("")}</div>`
    : `<p class="small" style="color:var(--ok)">Every committee has reported.</p>`}
  <div class="card" style="margin-top:12px">${ups.length ? ups.map(u => updateBlock(u) + `<p class="small" style="margin:2px 0 0 15px"><button class="linkish" data-del="${u.id}">Remove</button></p>`).join("") : `<p class="muted small" style="margin:0">No updates recorded yet.</p>`}</div>

  <div class="spread" style="margin-top:24px"><h3 style="margin:0">Decisions and other minutes</h3><button class="btn ghost small" id="editMinutes">${m.minutes ? "Edit" : "Write minutes"}</button></div>
  <div class="card pre" style="margin-top:8px">${m.minutes ? esc(m.minutes) : `<span class="muted small">Nothing written yet.</span>`}</div>

  <div class="spread" style="margin-top:24px"><h3 style="margin:0">Action points (${acts.length})</h3><button class="btn" id="addAct">Add action point</button></div>
  <p class="hint">Each action point is added to the checklist and comes up under matters arising at the next meeting until it's done.</p>
  <div class="card" style="margin-top:8px">${acts.length ? acts.map(t => apRow(t)).join("") : `<p class="small muted" style="margin:0">No action points yet.</p>`}</div>`;

  document.getElementById("share").onclick = () => shareMinutes(m);
  document.getElementById("editMtg").onclick = () => editMeeting(id);
  document.getElementById("editMinutes").onclick = () => editMeeting(id);
  document.getElementById("addUpd").onclick = () => addUpdate(id, S.me?.committee_id);
  document.getElementById("addAct").onclick = () => editTask(null, {
    source_meeting_id: id, section: ACTION_SECTION, committee_id: S.me?.committee_id,
    due_date: nextMeeting(m)?.meeting_date || addDays(m.meeting_date, 7),
  });
  document.getElementById("finalise")?.addEventListener("click", async e => {
    const v = e.target.dataset.v === "1";
    if (v && !m.minutes && !ups.length && !confirm("These minutes are empty. Mark them final anyway?")) return;
    await run(sb.from("meetings").update({ minutes_final: v, updated_at: new Date().toISOString() }).eq("id", id), v ? "Minutes marked final" : "Minutes reopened");
    await reload();
  });
  app.querySelectorAll("[data-c]").forEach(b => (b.onclick = () => addUpdate(id, Number(b.dataset.c))));
  app.querySelectorAll("[data-del]").forEach(b => (b.onclick = async () => {
    if (!confirm("Remove this update from the minutes?")) return;
    await run(sb.from("updates").delete().eq("id", Number(b.dataset.del)), "Update removed");
    await reload();
  }));
  bindTaskRows();
  bindStatusSelects();
}
function bindStatusSelects() {
  app.querySelectorAll("[data-status]").forEach(s => (s.onchange = async () => {
    await run(sb.from("tasks").update({ status: s.value, updated_at: new Date().toISOString(), updated_by: myName() }).eq("id", Number(s.dataset.status)), "Status updated");
    await reload();
  }));
}

function addUpdate(meetingId, committeeId) {
  const taskOpts = cid => opts(S.tasks.filter(t => !cid || t.committee_id === Number(cid)).map(t => ({ value: t.id, label: `${t.title} (${t.status})` })), "", { blank: "Not about one task" });
  openDialog(`
    <h2>Committee update</h2>
    <label for="uc">Committee</label><select id="uc" name="committee_id" required>${committeeOpts(committeeId)}</select>
    <label for="ua">Reported by</label><input id="ua" name="author" value="${esc(S.committees.find(c => c.id === committeeId)?.lead || myName())}">
    <label for="ut">Which task is this about?</label><select id="ut" name="task_id">${taskOpts(committeeId)}</select>
    <div id="nsWrap" hidden><label for="ns">Change that task's status to</label><select id="ns" name="new_status">${opts(STATUSES, "", { blank: "Leave as it is" })}</select></div>
    <label for="ud">What has been done</label><textarea id="ud" name="done" required></textarea>
    <label for="un">Next steps</label><textarea id="un" name="next_steps" style="min-height:60px"></textarea>
    <label for="ub">Needs help with (optional)</label><textarea id="ub" name="blockers" style="min-height:50px"></textarea>
    ${actionsBar({ save: "Save update" })}`,
    async fd => {
      const row = clean({ ...fd, meeting_id: meetingId, wedding_id: S.W.id });
      row.committee_id = numOrNull(row.committee_id);
      row.task_id = numOrNull(row.task_id);
      if (!row.task_id) row.new_status = null;
      row.author = row.author || myName();
      await run(sb.from("updates").insert(row));
      if (row.task_id && row.new_status)
        await run(sb.from("tasks").update({ status: row.new_status, updated_at: new Date().toISOString(), updated_by: myName() }).eq("id", row.task_id));
      toast("Update saved");
      await reload();
    },
    () => {
      const uc = document.getElementById("uc"), ut = document.getElementById("ut"), ns = document.getElementById("nsWrap"), ua = document.getElementById("ua");
      uc.onchange = () => { ut.innerHTML = taskOpts(uc.value); ns.hidden = true; const c = S.committees.find(x => x.id === Number(uc.value)); if (c?.lead) ua.value = c.lead; };
      ut.onchange = () => { ns.hidden = !ut.value; };
    });
}

/* ---------- sharing minutes ---------- */
function minutesData(m) {
  return {
    m, ma: mattersArising(m), acts: actionsOf(m), next: nextMeeting(m),
    ups: S.updates.filter(u => u.meeting_id === m.id).sort((a, b) => a.created_at.localeCompare(b.created_at)),
  };
}
function minutesText(m) {
  const { ma, ups, acts, next } = minutesData(m);
  const L = [];
  L.push(`*${S.W.couple} wedding – committee meeting minutes*`);
  L.push(`${fmtLong(m.meeting_date)}${m.start_time ? ", " + m.start_time : ""}${m.place ? " · " + m.place : ""}`);
  if (m.chair || m.minutes_taker) L.push([m.chair && `Chair: ${m.chair}`, m.minutes_taker && `Minutes: ${m.minutes_taker}`].filter(Boolean).join(" · "));
  if (!m.minutes_final) L.push("_Draft – not yet final_");
  L.push("");
  if (m.attendees) L.push(`*Present:* ${m.attendees.replace(/\n+/g, ", ")}`);
  if (m.apologies) L.push(`*Apologies:* ${m.apologies}`);
  if (ma.open.length || ma.closed.length) {
    L.push("", "*Matters arising*");
    ma.closed.forEach(t => L.push(`✅ ${t.title}${t.responsible ? ` (${t.responsible})` : ""} – done`));
    ma.open.forEach(t => L.push(`• ${t.title}${t.responsible ? ` (${t.responsible})` : ""} – ${t.status.toLowerCase()}${t.due_date ? `, due ${fmtDate(t.due_date)}` : ""}${isLate(t) ? " ⚠️ overdue" : ""}`));
  }
  if (ups.length) {
    L.push("", "*Committee updates*");
    ups.forEach(u => {
      const task = S.tasks.find(t => t.id === u.task_id);
      L.push(`_${cName(u.committee_id)}_${u.author ? ` (${u.author})` : ""}`);
      if (task) L.push(`Task: ${task.title}${u.new_status ? ` → ${u.new_status}` : ""}`);
      L.push(`Done: ${u.done}`);
      if (u.next_steps) L.push(`Next: ${u.next_steps}`);
      if (u.blockers) L.push(`Needs help: ${u.blockers}`);
      L.push("");
    });
    L.pop();
  }
  if (m.minutes) L.push("", "*Decisions and other minutes*", m.minutes);
  if (acts.length) {
    L.push("", "*Action points*");
    acts.forEach((t, i) => L.push(`${i + 1}. ${t.title} – ${t.responsible || "owner to be agreed"}${t.due_date ? `, by ${fmtDate(t.due_date)}` : ""}${t.status === "Done" ? " ✅" : ""}`));
  }
  if (next) L.push("", `*Next meeting:* ${fmtLong(next.meeting_date)}${next.start_time ? ", " + next.start_time : ""}${next.place ? " · " + next.place : ""}`);
  return L.join("\n");
}
function minutesHtml(m) {
  const { ma, ups, acts, next } = minutesData(m);
  const row = (k, v) => (v ? `<p><b>${esc(k)}:</b> ${nl(v)}</p>` : "");
  return `<h1>${esc(S.W.couple)} wedding – committee meeting minutes</h1>
  <div class="meta">${esc(fmtLong(m.meeting_date))}${m.start_time ? ", " + esc(m.start_time) : ""}${m.place ? " · " + esc(m.place) : ""}${m.minutes_final ? "" : " · DRAFT"}</div>
  ${row("Chair", m.chair)}${row("Minutes taken by", m.minutes_taker)}${row("Present", m.attendees)}${row("Apologies", m.apologies)}
  ${ma.open.length || ma.closed.length ? `<h2>Matters arising</h2><table><tr><th>Action</th><th>Owner</th><th>Due</th><th>Status</th></tr>
    ${[...ma.closed, ...ma.open].map(t => `<tr><td>${esc(t.title)}</td><td>${esc(t.responsible || "")}</td><td>${esc(fmtDate(t.due_date))}</td><td>${esc(t.status)}</td></tr>`).join("")}</table>` : ""}
  ${ups.length ? `<h2>Committee updates</h2>${ups.map(u => { const task = S.tasks.find(t => t.id === u.task_id);
    return `<div class="upd"><p><b>${esc(cName(u.committee_id))}</b>${u.author ? ` (${esc(u.author)})` : ""}</p>
      ${task ? `<p>Task: ${esc(task.title)}${u.new_status ? ` → ${esc(u.new_status)}` : ""}</p>` : ""}
      <p>Done: ${nl(u.done)}</p>${u.next_steps ? `<p>Next: ${nl(u.next_steps)}</p>` : ""}${u.blockers ? `<p>Needs help: ${nl(u.blockers)}</p>` : ""}</div>`; }).join("")}` : ""}
  ${m.minutes ? `<h2>Decisions and other minutes</h2><p>${nl(m.minutes)}</p>` : ""}
  ${acts.length ? `<h2>Action points</h2><table><tr><th>#</th><th>Action</th><th>Owner</th><th>Due</th></tr>
    ${acts.map((t, i) => `<tr><td>${i + 1}</td><td>${esc(t.title)}</td><td>${esc(t.responsible || "")}</td><td>${esc(fmtDate(t.due_date))}</td></tr>`).join("")}</table>` : ""}
  ${next ? `<h2>Next meeting</h2><p>${esc(fmtLong(next.meeting_date))}${next.start_time ? ", " + esc(next.start_time) : ""}${next.place ? " · " + esc(next.place) : ""}</p>` : ""}`;
}
function shareMinutes(m) {
  const text = minutesText(m);
  openDialog(`
    <h2>Share minutes</h2>
    ${m.minutes_final ? "" : `<p class="small" style="color:var(--warn);margin-top:-4px">These minutes aren't marked final yet, so they're labelled as a draft.</p>`}
    <div class="share-preview" id="sharePreview">${esc(text)}</div>
    <div class="actions">
      <a class="btn" id="waBtn" href="https://wa.me/?text=${encodeURIComponent(text)}" target="_blank" rel="noopener">Send on WhatsApp</a>
      <button type="button" class="btn ghost" id="copyBtn">Copy text</button>
      <button type="button" class="btn ghost" id="printBtn">Print or save as PDF</button>
      ${navigator.share ? `<button type="button" class="btn ghost" id="nativeShare">More…</button>` : ""}
      <button class="btn ghost left" value="cancel" formnovalidate>Close</button>
    </div>`, async () => {}, () => {
    document.getElementById("copyBtn").onclick = async () => {
      try { await navigator.clipboard.writeText(text); toast("Minutes copied. Paste them into your group."); }
      catch { const r = document.createRange(); r.selectNodeContents(document.getElementById("sharePreview")); const s = getSelection(); s.removeAllRanges(); s.addRange(r); toast("Text selected. Copy it with your device's copy option."); }
    };
    document.getElementById("printBtn").onclick = () => {
      document.getElementById("print").innerHTML = minutesHtml(m);
      dlg.close();
      setTimeout(() => window.print(), 50);
    };
    document.getElementById("nativeShare")?.addEventListener("click", () => navigator.share({ title: `${S.W.couple} – meeting minutes`, text }).catch(() => {}));
  });
}

/* ================= Budget ================= */
function viewBudget() {
  if (!S.lists.length) {
    app.innerHTML = `<div class="spread"><h2>Budget</h2><button class="btn" id="addList">New budget list</button></div>
      <div class="empty card">No budget lists yet. Add one per quote or area, for example "Food – caterer's quote" or "Decor".</div>`;
    document.getElementById("addList").onclick = () => editList(null);
    return;
  }
  const L = S.lists.find(l => l.id === ui.listId) || S.lists[0];
  ui.listId = L.id;
  const items = S.items.filter(i => i.list_id === L.id);
  const cats = [...new Set(items.map(f => f.category))];
  const total = items.reduce((s, f) => s + Number(f.amount), 0);
  const bought = items.filter(f => f.bought).reduce((s, f) => s + Number(f.amount), 0);
  const all = S.items.reduce((s, f) => s + Number(f.amount), 0);
  app.innerHTML = `
  <div class="spread"><h2>Budget</h2><button class="btn ghost" id="addList">New list</button></div>
  ${S.lists.length > 1 ? `<div class="chips" style="margin-bottom:10px">${S.lists.map(l => `<a class="chip" href="#budget-${l.id}" aria-pressed="${l.id === L.id}" style="text-decoration:none">${esc(l.name)}</a>`).join("")}</div>
    <p class="small muted">All lists together: ${money(all)}</p>` : ""}
  <div class="card stack">
    <div class="spread"><b style="font-size:17px">${esc(L.name)}</b><button class="btn ghost small" id="editList">Edit list</button></div>
    ${L.supplier || L.contact ? `<div class="small">${esc([L.supplier, L.contact].filter(Boolean).join(" · "))}</div>` : ""}
    ${L.notes ? `<div class="small muted pre">${esc(L.notes)}</div>` : ""}
  </div>
  <div class="grid2" style="margin-top:12px">
    <div class="card stat"><div class="muted small">Total</div><div class="n">${money(total)}</div></div>
    <div class="card stat"><div class="muted small">Bought or paid</div><div class="n">${money(bought)}</div>
      <div class="bar"><i style="width:${total ? Math.round(bought / total * 100) : 0}%"></i></div></div>
    <div class="card stat"><div class="muted small">Still to buy</div><div class="n">${money(total - bought)}</div></div>
  </div>
  <div class="spread" style="margin-top:18px"><span class="small muted">Tick items as they're bought. Change an amount and it saves straight away.</span><button class="btn" id="addItem">Add item</button></div>
  ${cats.map(cat => {
    const its = items.filter(f => f.category === cat);
    const sub = its.reduce((s, f) => s + Number(f.amount), 0);
    return `<h3>${esc(cat)}</h3><div class="tablewrap"><table class="food"><tbody>
      ${its.map(f => `<tr class="${f.bought ? "bought" : ""}">
        <td class="chk"><input type="checkbox" data-buy="${f.id}" ${f.bought ? "checked" : ""} aria-label="Bought: ${esc(f.item)}"></td>
        <td><button type="button" class="linkish" style="color:inherit;text-decoration:none;font-size:14px;text-align:left" data-fedit="${f.id}">${esc(f.item)}</button>${f.detail ? `<div class="small muted">${esc(f.detail)}</div>` : ""}${f.notes ? `<div class="small" style="color:var(--wine)">${esc(f.notes)}</div>` : ""}</td>
        <td class="amt"><input type="number" step="0.01" min="0" inputmode="decimal" value="${Number(f.amount).toFixed(2)}" data-amt="${f.id}" aria-label="Amount for ${esc(f.item)}"></td></tr>`).join("")}
      </tbody><tfoot><tr><td></td><td>Subtotal</td><td class="amt">${money(sub)}</td></tr></tfoot></table></div>`;
  }).join("") || `<div class="empty">No items in this list yet.</div>`}`;
  document.getElementById("addList").onclick = () => editList(null);
  document.getElementById("editList").onclick = () => editList(L.id);
  document.getElementById("addItem").onclick = () => editItem(null);
  app.querySelectorAll("[data-buy]").forEach(c => (c.onchange = async () => {
    await run(sb.from("budget_items").update({ bought: c.checked }).eq("id", Number(c.dataset.buy)));
    await reload();
  }));
  app.querySelectorAll("[data-amt]").forEach(i => (i.onchange = async () => {
    await run(sb.from("budget_items").update({ amount: Number(i.value || 0) }).eq("id", Number(i.dataset.amt)), "Amount saved");
    await reload();
  }));
  app.querySelectorAll("[data-fedit]").forEach(b => (b.onclick = () => editItem(Number(b.dataset.fedit))));
}

function editList(id) {
  const l = S.lists.find(x => x.id === id) || {};
  openDialog(`
    <h2>${id ? "Edit budget list" : "New budget list"}</h2>
    <label for="ln">Name</label><input id="ln" name="name" required value="${esc(l.name)}" placeholder="e.g. Food – caterer's quote">
    <div class="grid2">
      <div><label for="ls">Supplier</label><input id="ls" name="supplier" value="${esc(l.supplier)}"></div>
      <div><label for="lc">Contact</label><input id="lc" name="contact" value="${esc(l.contact)}"></div>
    </div>
    <label for="lno">Notes</label><textarea id="lno" name="notes">${esc(l.notes)}</textarea>
    ${actionsBar({ save: "Save list", del: id ? "Delete list" : null })}`,
    async (fd, action) => {
      if (action === "delete") {
        if (!confirm(`Delete "${l.name}" and all its items? This can't be undone.`)) throw new Error("cancelled");
        await run(sb.from("budget_lists").delete().eq("id", id), "List deleted");
        ui.listId = null; await loadWedding(); go("#budget");
      } else if (id) { await run(sb.from("budget_lists").update(clean(fd)).eq("id", id), "List saved"); await reload(); }
      else {
        const rows = await run(sb.from("budget_lists").insert({ ...clean(fd), wedding_id: S.W.id, sort: Math.max(0, ...S.lists.map(x => x.sort)) + 1 }).select(), "List added");
        ui.listId = rows[0].id; await loadWedding(); go("#budget-" + rows[0].id);
      }
    });
}

function editItem(id) {
  const items = S.items.filter(i => i.list_id === ui.listId);
  const f = S.items.find(x => x.id === id) || { category: items[items.length - 1]?.category || "General", amount: 0 };
  const cats = [...new Set(items.map(x => x.category))];
  openDialog(`
    <h2>${id ? "Edit item" : "New item"}</h2>
    <label for="fi">Item</label><input id="fi" name="item" required value="${esc(f.item)}">
    <div class="grid2">
      <div><label for="fd">Quantity / detail</label><input id="fd" name="detail" value="${esc(f.detail)}"></div>
      <div><label for="fa">Amount (USD)</label><input id="fa" name="amount" type="number" step="0.01" min="0" inputmode="decimal" required value="${esc(f.amount)}"></div>
    </div>
    <label for="fcat">Group</label><input id="fcat" name="category" list="catList" required value="${esc(f.category)}">
    <datalist id="catList">${cats.map(c => `<option value="${esc(c)}">`).join("")}</datalist>
    <label for="fn">Notes</label><input id="fn" name="notes" value="${esc(f.notes)}">
    ${actionsBar({ save: "Save item", del: id ? "Delete" : null })}`,
    async (fd, action) => {
      if (action === "delete") {
        if (!confirm("Delete this item?")) throw new Error("cancelled");
        await run(sb.from("budget_items").delete().eq("id", id), "Item deleted");
      } else {
        const row = clean(fd); row.amount = Number(row.amount || 0);
        if (id) await run(sb.from("budget_items").update(row).eq("id", id), "Item saved");
        else await run(sb.from("budget_items").insert({ ...row, wedding_id: S.W.id, list_id: ui.listId, sort: Math.max(0, ...S.items.map(x => x.sort)) + 1 }), "Item added");
      }
      await reload();
    });
}

/* ================= Team & settings ================= */
async function viewTeam() {
  const mg = canManage();
  app.innerHTML = `
  <h2>Team</h2>
  <div class="spread"><h3 style="margin:0">Committees</h3>${mg ? `<button class="btn ghost" id="addCom">Add committee</button>` : ""}</div>
  <div class="stack" style="margin-top:10px">${S.committees.map(c => {
    const open = S.tasks.filter(t => t.committee_id === c.id && t.status !== "Done").length;
    const late = S.tasks.filter(t => t.committee_id === c.id && isLate(t)).length;
    const people = S.members.filter(m => m.committee_id === c.id).map(m => m.name || m.email);
    return `<div class="card spread"><div><div style="font-weight:600">${esc(c.name)}</div>
      <div class="small muted">Lead: ${esc(c.lead || "not set")}${people.length ? ` · ${esc(people.join(", "))}` : ""}</div>
      <div class="small">${plural(open, "open task")}${late ? ` · <span class="late">${late} overdue</span>` : ""} · <button class="linkish" data-cf="${c.id}">View tasks</button></div></div>
      ${mg ? `<button class="btn ghost small" data-ce="${c.id}">Edit</button>` : ""}</div>`;
  }).join("") || `<p class="muted small">No committees yet.</p>`}</div>

  <div class="spread" style="margin-top:24px"><h3 style="margin:0">People who can sign in</h3>${mg ? `<button class="btn" id="addMem">Add person</button>` : ""}</div>
  ${mg ? `<p class="hint">Add someone's email, then send them this site's link. They sign in with a code sent to that email.</p>` : `<p class="hint">Only the planner can add or remove people.</p>`}
  <div class="stack" style="margin-top:10px">${S.members.map(m => `<div class="card spread"><div>
      <div style="font-weight:600">${esc(m.name || "No name")} <span class="pill">${esc(ROLES[m.role])}</span></div>
      <div class="small muted">${esc(m.email)} · ${esc(cName(m.committee_id))}</div></div>
      ${mg && (m.role !== "owner" || isOwner()) ? `<button class="btn ghost small" data-me="${m.id}">Edit</button>` : ""}</div>`).join("")}</div>

  ${mg ? `<h3>Wedding settings</h3>
  <div class="card stack">
    <div class="small">${esc(S.W.couple)} · ${esc(fmtLong(S.W.wedding_date))}${S.W.venue ? ` · ${esc(S.W.venue)}` : ""}${S.W.guest_count ? ` · ${S.W.guest_count} guests` : ""}</div>
    <div class="row">
      <button class="btn ghost" id="editWedding">Edit wedding details</button>
      ${isOwner() ? `<button class="btn ghost" id="archive">${S.W.status === "archived" ? "Unarchive" : "Archive after the wedding"}</button>` : ""}
      ${S.isAppAdmin ? `<button class="btn ghost" id="saveTpl">Use this checklist for future weddings</button>` : ""}
    </div>
    ${isOwner() ? `<button class="linkish" id="delWedding" style="color:var(--danger);align-self:flex-start">Delete this wedding permanently</button>` : ""}
  </div>` : ""}

  ${S.isAppAdmin ? `<h3>Planners who can create weddings</h3><div class="card" id="admins"><span class="small muted">Loading…</span></div>` : ""}`;

  app.querySelectorAll("[data-cf]").forEach(b => (b.onclick = () => { ui.taskFilter = { committee: b.dataset.cf, status: "open", q: "" }; go("#checklist"); }));
  if (mg) {
    document.getElementById("addCom").onclick = () => editCommittee(null);
    document.getElementById("addMem").onclick = () => editMember(null);
    document.getElementById("editWedding").onclick = () => editWedding();
    app.querySelectorAll("[data-ce]").forEach(b => (b.onclick = () => editCommittee(Number(b.dataset.ce))));
    app.querySelectorAll("[data-me]").forEach(b => (b.onclick = () => editMember(Number(b.dataset.me))));
  }
  document.getElementById("archive")?.addEventListener("click", async () => {
    const to = S.W.status === "archived" ? "active" : "archived";
    await run(sb.from("weddings").update({ status: to }).eq("id", S.W.id), to === "archived" ? "Wedding archived" : "Wedding unarchived");
    await reload();
  });
  document.getElementById("saveTpl")?.addEventListener("click", async () => {
    if (!confirm("Replace the standard plan with this wedding's committees and checklist? New weddings will start from it. Dates are kept as 'days before the wedding'; meeting action points are left out.")) return;
    const n = await run(sb.rpc("save_wedding_as_template", { p_wedding: S.W.id }));
    toast(`Standard plan updated with ${plural(n, "task")}`);
  });
  document.getElementById("delWedding")?.addEventListener("click", async () => {
    const typed = prompt(`This deletes ${S.W.couple}'s checklist, meetings, minutes and budget for everyone. Type the couple's names exactly to confirm:\n${S.W.couple}`);
    if (typed !== S.W.couple) { if (typed !== null) toast("Names didn't match, so nothing was deleted.", true); return; }
    await run(sb.from("weddings").delete().eq("id", S.W.id), "Wedding deleted");
    store.set("weddingId", "");
    boot(S.session);
  });
  if (S.isAppAdmin) renderAdmins();
}

async function renderAdmins() {
  const box = document.getElementById("admins");
  const { data, error } = await sb.from("app_admins").select("*").order("email");
  if (!box) return;
  if (error) { box.textContent = friendly(error); return; }
  box.innerHTML = `${data.map(a => `<div class="spread small" style="padding:6px 0"><span>${esc(a.name || "")} ${esc(a.email)}</span>
      ${a.email !== S.email ? `<button class="linkish" data-rmadmin="${esc(a.email)}">Remove</button>` : `<span class="muted">you</span>`}</div>`).join("")}
    <form id="adminForm" class="row" style="margin-top:8px;flex-wrap:nowrap"><input name="email" type="email" required placeholder="planner@email.com" aria-label="Planner email"><button class="btn small">Add</button></form>
    <p class="hint">They can create new weddings and become the owner of each one they create. They don't see other weddings unless added to that wedding's team.</p>`;
  box.querySelectorAll("[data-rmadmin]").forEach(b => (b.onclick = async () => {
    if (!confirm(`Stop ${b.dataset.rmadmin} from creating weddings?`)) return;
    await run(sb.from("app_admins").delete().eq("email", b.dataset.rmadmin), "Removed");
    renderAdmins();
  }));
  document.getElementById("adminForm").onsubmit = async e => {
    e.preventDefault();
    await run(sb.from("app_admins").insert({ email: e.target.email.value.trim().toLowerCase() }), "Planner added");
    renderAdmins();
  };
}

function editCommittee(id) {
  const c = S.committees.find(x => x.id === id) || {};
  openDialog(`
    <h2>${id ? "Edit committee" : "New committee"}</h2>
    <label for="cn">Name</label><input id="cn" name="name" required value="${esc(c.name)}">
    <label for="cl">Lead</label><input id="cl" name="lead" value="${esc(c.lead)}">
    ${actionsBar({ save: "Save committee", del: id ? "Delete" : null })}`,
    async (fd, action) => {
      if (action === "delete") {
        if (!confirm("Delete this committee? Its tasks and updates stay, but won't belong to a committee.")) throw new Error("cancelled");
        await run(sb.from("committees").delete().eq("id", id), "Committee deleted");
      } else if (id) await run(sb.from("committees").update(clean(fd)).eq("id", id), "Committee saved");
      else await run(sb.from("committees").insert({ ...clean(fd), wedding_id: S.W.id, sort: Math.max(0, ...S.committees.map(x => x.sort)) + 1 }), "Committee added");
      await reload();
    });
}

function editMember(id) {
  const m = S.members.find(x => x.id === id) || { role: "member" };
  const self = m.email === S.email;
  const roleChoices = Object.entries(ROLES).filter(([k]) => k !== "owner" || isOwner()).map(([value, label]) => ({ value, label }));
  openDialog(`
    <h2>${id ? "Edit person" : "Add person"}</h2>
    <label for="pe">Email</label><input id="pe" name="email" type="email" required value="${esc(m.email)}" ${id ? "readonly" : ""}>
    ${id ? `<p class="hint">To change an email, remove this person and add them again.</p>` : ""}
    <label for="pn">Name</label><input id="pn" name="name" required value="${esc(m.name)}">
    <label for="pc">Committee</label><select id="pc" name="committee_id">${committeeOpts(m.committee_id)}</select>
    <label for="pr">Role</label><select id="pr" name="role" ${self ? "disabled" : ""}>${opts(roleChoices, m.role)}</select>
    <p class="hint">Committee members use the checklist, meetings and budget. Planners can also manage people and committees. Owners can do everything.</p>
    ${actionsBar({ save: "Save person", del: id && !self ? "Remove" : null })}`,
    async (fd, action) => {
      if (action === "delete") {
        if (!confirm(`Remove ${m.name || m.email}? They won't be able to sign in to this wedding.`)) throw new Error("cancelled");
        await run(sb.from("wedding_members").delete().eq("id", id), "Person removed");
      } else {
        const row = { name: fd.name.trim(), committee_id: numOrNull(fd.committee_id) };
        if (!self) row.role = fd.role;
        if (id) await run(sb.from("wedding_members").update(row).eq("id", id), "Person saved");
        else await run(sb.from("wedding_members").insert({ ...row, email: fd.email.trim().toLowerCase(), wedding_id: S.W.id }), "Person added. Send them the link to this site.");
      }
      await reload();
    });
}

function editWedding() {
  const W = S.W;
  openDialog(`
    <h2>Wedding details</h2>
    <label for="wc">Couple</label><input id="wc" name="couple" required value="${esc(W.couple)}">
    <div class="grid2">
      <div><label for="wd">Wedding date</label><input id="wd" name="wedding_date" type="date" required value="${esc(W.wedding_date)}"></div>
      <div><label for="wg">Expected guests</label><input id="wg" name="guest_count" type="number" min="0" value="${esc(W.guest_count)}"></div>
    </div>
    <label for="wv">Venue</label><input id="wv" name="venue" value="${esc(W.venue)}">
    <label for="wa">Venue address</label><input id="wa" name="venue_address" value="${esc(W.venue_address)}">
    <label for="wn">Notes</label><textarea id="wn" name="notes">${esc(W.notes)}</textarea>
    <p class="hint">Changing the date doesn't move checklist due dates.</p>
    ${actionsBar({ save: "Save details" })}`,
    async fd => {
      const row = clean(fd); row.guest_count = numOrNull(row.guest_count);
      await run(sb.from("weddings").update(row).eq("id", W.id), "Wedding saved");
      await reload();
    });
}

/* ================= switching and creating weddings ================= */
function switchWeddingDialog() {
  const t0 = todayISO();
  const order = [...S.weddings].sort((a, b) => (a.status === b.status ? 0 : a.status === "active" ? -1 : 1) || a.wedding_date.localeCompare(b.wedding_date));
  openDialog(`
    <h2>Your weddings</h2>
    <div class="stack">${order.map(w => `<button type="button" class="task" data-w="${w.id}" ${S.W?.id === w.id ? 'aria-current="true" style="border-color:var(--gold)"' : ""}>
      <span class="dot ${w.wedding_date < t0 ? "done" : ""}" aria-hidden="true"></span>
      <span class="t">${esc(w.couple)}</span>
      <span class="meta"><span>${esc(fmtLong(w.wedding_date))}</span>${w.venue ? `<span>${esc(w.venue)}</span>` : ""}${w.status === "archived" ? `<span class="pill">Archived</span>` : ""}</span>
    </button>`).join("")}</div>
    <div class="actions">
      ${S.isAppAdmin ? `<button type="button" class="btn" id="newWedding">Create a new wedding</button>` : ""}
      <button class="btn ghost left" value="cancel" formnovalidate>Close</button>
    </div>`, async () => {}, () => {
    dlgForm.querySelectorAll("[data-w]").forEach(b => (b.onclick = async () => { dlg.close(); location.hash = "#today"; await openWedding(b.dataset.w); }));
    document.getElementById("newWedding")?.addEventListener("click", () => createWeddingDialog());
  });
}

const weddingFormFields = () => `
  <label for="nc">Couple</label><input id="nc" name="couple" required placeholder="e.g. Rudo & Tafadzwa">
  <div class="grid2">
    <div><label for="nd">Wedding date</label><input id="nd" name="date" type="date" required></div>
    <div><label for="ng">Expected guests</label><input id="ng" name="guests" type="number" min="0"></div>
  </div>
  <label for="nv">Venue</label><input id="nv" name="venue">
  <label for="na">Venue address</label><input id="na" name="address">
  <label for="nm">Your name</label><input id="nm" name="owner_name" required value="${esc(S.me?.name || "")}">
  <label class="check"><input type="checkbox" name="use_template" checked> Start with the standard committees and checklist</label>
  <p class="hint">Checklist dates are worked out from the wedding date. Anything that should already have been done is put under "Catch up first".</p>`;

async function submitNewWedding(fd) {
  const id = await run(sb.rpc("create_wedding", {
    p_couple: fd.couple, p_date: fd.date, p_venue: fd.venue || null, p_venue_address: fd.address || null,
    p_guest_count: numOrNull(fd.guests), p_owner_name: fd.owner_name, p_use_template: fd.use_template === "on",
  }), "Wedding created");
  store.set("weddingId", id);
  location.hash = "#team";
  await boot(S.session);
}
function createWeddingDialog() {
  openDialog(`<h2>New wedding</h2>${weddingFormFields()}${actionsBar({ save: "Create wedding" })}`, submitNewWedding);
}
function createWeddingScreen() {
  app.innerHTML = `<div class="narrow card"><h2>Create your first wedding</h2><form id="firstWedding">${weddingFormFields()}
    <div class="actions"><button class="btn">Create wedding</button></div></form></div>`;
  document.getElementById("firstWedding").onsubmit = async e => {
    e.preventDefault();
    e.submitter.disabled = true;
    try { await submitNewWedding(Object.fromEntries(new FormData(e.target))); } catch (_) { e.submitter.disabled = false; }
  };
}
