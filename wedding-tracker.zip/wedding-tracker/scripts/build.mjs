// Copies src/ to dist/ and writes dist/config.js from environment variables.
// Vercel runs this automatically (see vercel.json). Locally: `npm run build` or `npm run dev`.
import { cpSync, rmSync, writeFileSync, readFileSync, existsSync } from "node:fs";

// Load .env for local builds (Vercel provides real environment variables).
if (existsSync(".env")) {
  for (const line of readFileSync(".env", "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
}

// Works with keys you add yourself or ones the Vercel Marketplace Supabase integration adds
// (newer projects get SUPABASE_PUBLISHABLE_KEY instead of SUPABASE_ANON_KEY).
const pick = (...names) => (names.map(n => process.env[n]).find(v => v && v.trim()) || "").trim();
const url = pick("SUPABASE_URL", "NEXT_PUBLIC_SUPABASE_URL");
const key = pick("SUPABASE_ANON_KEY", "SUPABASE_PUBLISHABLE_KEY", "NEXT_PUBLIC_SUPABASE_ANON_KEY", "NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY");

if (!url || !key) {
  const msg = "SUPABASE_URL and SUPABASE_ANON_KEY (or SUPABASE_PUBLISHABLE_KEY) must be set (Vercel → Settings → Environment Variables, or a local .env file).";
  if (process.env.VERCEL) { console.error("✖ " + msg); process.exit(1); }
  console.warn("⚠ " + msg + " Building with placeholders.");
}
if (url && !/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(url)) {
  console.warn("⚠ SUPABASE_URL doesn't look like https://<project>.supabase.co – check it if sign-in fails.");
}
if (key && key.split(".").length === 3) {
  try {
    const role = JSON.parse(Buffer.from(key.split(".")[1], "base64url").toString()).role;
    if (role === "service_role") { console.error("✖ That is the service_role key. Use the anon / publishable key – the service key must never go in a website."); process.exit(1); }
  } catch { /* not a JWT-style key; fine */ }
}
if (/^sb_secret_/.test(key)) { console.error("✖ That is a secret key. Use the publishable (anon) key."); process.exit(1); }

rmSync("dist", { recursive: true, force: true });
cpSync("src", "dist", { recursive: true });
writeFileSync("dist/config.js",
  `window.APP_CONFIG = ${JSON.stringify({ SUPABASE_URL: url || "https://YOUR-PROJECT.supabase.co", SUPABASE_ANON_KEY: key || "YOUR-ANON-KEY" })};\n`);
console.log("✔ Built dist/");
