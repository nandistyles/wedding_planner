# Wedding tracker

A planning app for wedding committees. Each wedding gets:

- a **checklist** with due dates, committees and the person responsible
- **committee meetings with proper minutes**: attendance, matters arising, committee updates, decisions and action points, shared on WhatsApp or printed when they're done
- **budget lists** (one per quote or area) with a tick box for each item as it's bought
- a **team** of people who sign in with an email code, each with a role

One deployment runs any number of weddings. Each wedding's data is visible only to the people on its team.

It's a static site (plain HTML, CSS and JavaScript) hosted on Vercel, with Supabase as the database and sign-in.

---

## What's in this repository

```
src/                      the app (index.html, app.js, styles.css)
scripts/build.mjs         copies src/ to dist/ and writes config.js from environment variables
vercel.json               build settings and security headers for Vercel
supabase/
  migrations/0001_init.sql        tables, access rules and functions (run once)
  seed/0002_standard_plan.sql     standard committees and checklist for new weddings
  seed/0003_mercy_garikai.sql     Mercy & Garikai's real plan and Christec food quote
  drop_v1_tables.sql              only if you ran the very first single-wedding setup file
.env.example              settings template for running on your own computer
```

---

## Setup

Allow about 30 minutes the first time.

### 1. Create the Supabase project

1. Go to [supabase.com](https://supabase.com), create a project, and wait for it to finish setting up.
2. Open **SQL Editor → New query**. Paste in each file below, in this order, and press **Run** after each one:
   1. `supabase/migrations/0001_init.sql`
   2. `supabase/seed/0002_standard_plan.sql`
   3. `supabase/seed/0003_mercy_garikai.sql`. **Before running it, change `owner_email` near the top to the email you'll sign in with.** That email becomes the wedding's owner and an app admin, so it can create future weddings.

   If you already ran the earlier single-file version (`supabase_setup.sql`), run `supabase/drop_v1_tables.sql` first. It deletes those tables and any data in them.

   To start a fresh project without Mercy & Garikai, skip file 3. Instead, add yourself as an app admin with this query:

   ```sql
   insert into app_admins (email, name) values ('you@example.com', 'Your name');
   ```

   You'll then create your first wedding inside the app.

### 2. Set up sign-in

In Supabase, go to **Authentication**:

- **URL Configuration**
  - **Site URL:** your Vercel address once you have it, e.g. `https://wedding-tracker.vercel.app`.
  - **Redirect URLs:** add the same address, plus `http://localhost:3000` if you'll run the app on your own computer.
- **Email Templates:** edit both **Magic Link** and **Confirm signup** so they include the six-digit code as well as the link. For example, add:

  ```html
  <p>Your sign-in code is <strong>{{ .Token }}</strong></p>
  ```

  Committee members can then type the code into the app. Many people open email in a different app or browser from the one they started signing in on, and in that case the link alone won't sign them in.
- **Emails (SMTP):** Supabase's built-in email service only sends a few emails per hour. That's fine for testing, but once a whole committee is signing in, connect your own email service (for example Resend, Brevo, or a Gmail/Google Workspace account) under **Authentication → Emails → SMTP settings**.

### 3. Put the code on GitHub

Create an **empty** repository on GitHub. Don't add a README or .gitignore, because this repository already has them. Then do one of the following.

**With git on your computer** (this repository already has its first commit):

```bash
cd wedding-tracker
git remote add origin https://github.com/<your-username>/wedding-tracker.git
git branch -M main
git push -u origin main
```

**Without git:** on the new repository's page, choose **uploading an existing file**. Drag in everything inside the `wedding-tracker` folder, including the `.gitignore` file, which is hidden by default on Mac and Windows. Then commit.

### 4. Deploy on Vercel

**Shortcut:** instead of creating the Supabase project on supabase.com (step 1), you can create it from Vercel: open your Vercel project → **Storage → Create Database → Supabase**. Vercel then adds the URL and key environment variables for you, and this app picks them up automatically. You still run the SQL files (step 1) and set up sign-in (step 2) in Supabase's dashboard. Open it with the **Open in Supabase** button in Vercel.

**No GitHub?** You can deploy from your computer with the Vercel command line instead: in the `wedding-tracker` folder, run `npx vercel` and follow the prompts. You'll need to re-run `npx vercel --prod` after every change, because there's no automatic redeploy without a connected repository.

1. In Vercel, choose **Add New → Project** and import the GitHub repository. Leave the framework preset as **Other**; `vercel.json` already sets the build.
2. Before deploying, open **Environment Variables** and add:

   | Name | Value (from Supabase → Project Settings → API / API Keys) |
   |---|---|
   | `SUPABASE_URL` | Project URL, e.g. `https://abcd1234.supabase.co` |
   | `SUPABASE_ANON_KEY` | The **anon public** key, or the **publishable** key on newer projects |

   **Never use the `service_role` or secret key.** It bypasses all the access rules. The build stops with an error if you paste one in by mistake.
3. Choose **Deploy**. Copy the address Vercel gives you and put it into Supabase's Site URL and Redirect URLs (step 2).

Every push to `main` redeploys automatically.

### 5. Sign in

Open the site, enter your email, and type the code from the email. You'll land on your wedding. Then go to the **Team** tab and add your committee members.

---

## Using it

### Roles

| | Committee member | Planner | Owner |
|---|:-:|:-:|:-:|
| Checklist, meetings, minutes, updates, budget | ✓ | ✓ | ✓ |
| Add or remove people, edit committees and wedding details | | ✓ | ✓ |
| Delete a meeting | | ✓ | ✓ |
| Make someone an owner, archive or delete the wedding | | | ✓ |

**App admins** are a separate list of people who can create new weddings, held in the `app_admins` table. You can add other planners you work with from the Team tab. Being an app admin doesn't let anyone see other weddings; people only see weddings whose team they're on.

### Meetings and minutes

1. **Create the meeting** on the Meetings tab. A new meeting copies the place, time and chair from the previous one, and its date defaults to a week after it.
2. **Matters arising** fills itself in. It lists every action point from earlier meetings that isn't done yet, so you can change each status as you go round the table. Action points finished since the last meeting are listed as done.
3. **Committee updates:** tap a committee under "Still to report" to record what they did, their next steps and what they need help with. If an update is about a checklist task, you can change that task's status in the same form.
4. **Decisions and other minutes:** free text for anything else that was agreed.
5. **Action points:** each one gets an owner and a due date. It's added to the checklist straight away and appears under matters arising at every later meeting until it's done.
6. **Mark minutes final** when they're agreed. Until then, the meeting shows **Minutes outstanding**, both on the meeting and at the top of the Today tab.
7. **Share minutes** turns the whole meeting into a WhatsApp-ready message. You can send it on WhatsApp, copy it, or print it and save it as a PDF. Minutes that aren't final yet are labelled as a draft.

### Starting a new wedding

1. Choose **Switch wedding → Create a new wedding** (app admins only).
2. Leave **Start with the standard committees and checklist** ticked. The app works out each task's due date from the wedding date. If you're starting late, anything that should already have been done goes under **Catch up first**, due within a week.
3. Add the couple's committee members on the Team tab.

### Improving the standard plan

After a wedding, if its checklist turned out better than the standard one, open that wedding and go to **Team → Use this checklist for future weddings**. It replaces the standard plan with that wedding's committees and tasks. Dates are kept as "days before the wedding", and meeting action points are left out. You can also edit `supabase/seed/0002_standard_plan.sql` and run it again.

### After the wedding

Go to **Team → Archive after the wedding**. Archived weddings stay readable and move to the bottom of the wedding switcher.

---

## Good to know

- **The free Supabase plan pauses a project after about a week with no activity.** It's free to restore from the Supabase dashboard, but the app won't load until you do. A paid plan avoids this and adds daily backups.
- **Backups:** on the free plan, export the important tables now and then (Table Editor → a table → Export to CSV).
- **Privacy:** phone numbers, names and money are in this data. Every table is protected by row-level security in `0001_init.sql`, and the site only ever uses the public key. Add people by email only when they need access, and remove them afterwards.
- **Changing the wedding date** doesn't move existing checklist due dates. Adjust them on the checklist if needed.

## Running it on your own computer

You'll need Node 18 or newer.

```bash
cp .env.example .env    # then fill in SUPABASE_URL and SUPABASE_ANON_KEY
npm run dev             # builds and serves on http://localhost:3000
```

Add `http://localhost:3000` to Supabase's Redirect URLs so the sign-in link works locally.

## Troubleshooting

| What you see | Fix |
|---|---|
| "Almost there – this app doesn't know which Supabase project to use" | Set both environment variables in Vercel and redeploy. |
| The sign-in email has no code | Add `{{ .Token }}` to the Magic Link and Confirm signup email templates. |
| "Too many sign-in emails" | Supabase's built-in email limit. Wait, or set up your own SMTP. |
| Signed in, but "You're not on a wedding team yet" | Add that exact email on the Team tab of the wedding, or in `wedding_members`. |
| "You don't have permission to do that" | Your role on this wedding doesn't allow it. Ask the owner or a planner. |
| The site loads but nothing happens | Your Supabase project may be paused. Restore it from the Supabase dashboard. |
