-- Mercy & Garikai – 5 December 2026. Loads their real plan, committees and the Christec food quote.
-- BEFORE RUNNING: change owner_email below to the email you will sign in with.
-- This also makes that email an app admin, so it can create future weddings.
do $$
declare
  owner_email text := 'your-email@example.com';   -- <<< CHANGE THIS
  owner_name  text := 'Tatenda';
  w uuid;
  food bigint;
begin
  owner_email := lower(trim(owner_email));
  if owner_email = 'your-email@example.com' then
    raise exception 'Edit owner_email at the top of this file first.';
  end if;

  insert into app_admins (email, name) values (owner_email, owner_name) on conflict (email) do nothing;

  insert into weddings (couple, wedding_date, venue, venue_address, guest_count, notes, created_by)
  values ('Mercy & Garikai', '2026-12-05', 'Rainbow Ministries Auditorium', '3826 Warren Park, Harare', 700,
          'Church auditorium seats 500. No ZESA – generator and gas. Limited parking. One changing room. Needs 5,000 L water.',
          owner_email)
  returning id into w;

  insert into committees (wedding_id, name, lead, sort) values
    (w, 'Coordination', 'Tatenda', 0),
    (w, 'Finance', 'Finance team', 1),
    (w, 'Catering & cake', 'Mr Ngarande / Mrs Mvududu', 2),
    (w, 'Decor & seating', 'Mai Mandebvu', 3),
    (w, 'Bridal party & attire', 'Portia', 4),
    (w, 'Transport', 'Mr Matafi & Mr Musami', 5),
    (w, 'Security, parking & ushers', 'Mr Gwawawa', 6),
    (w, 'Programme, MC & music', 'Tich', 7),
    (w, 'Photo & video', 'Naison Chigidi', 8),
    (w, 'Venue, power & water', 'MK', 9);

  insert into wedding_members (wedding_id, email, name, role, committee_id)
  values (w, owner_email, owner_name, 'owner', (select id from committees where wedding_id = w and name = 'Coordination'));

  insert into tasks (wedding_id, section, title, due_date, committee_id, responsible, status, notes, sort) values
    (w, 'Urgent – This Week', '★ Confirm church auditorium booking, date & times with pastor', '2026-11-14', (select id from committees where wedding_id = w and name = 'Venue, power & water'), 'Tatenda', 'Done', null, 0),
    (w, 'Urgent – This Week', '★ Sign church contract by 21st of Nov', '2026-11-21', (select id from committees where wedding_id = w and name = 'Venue, power & water'), 'Tatenda', 'In progress', 'Mk to follow up with Pastor Shonai, for costs for venue', 1),
    (w, 'Urgent – This Week', 'Finalise food budget', '2026-11-21', (select id from committees where wedding_id = w and name = 'Catering & cake'), null, 'Not started', null, 2),
    (w, 'Urgent – This Week', 'Book marriage officer & check documents needed (allow processing time)', '2026-11-14', (select id from committees where wedding_id = w and name = 'Coordination'), null, 'Not started', null, 3),
    (w, 'Urgent – This Week', 'Book MC, DJ & sound – ★ tell DJ the church PA exists', '2026-11-14', (select id from committees where wedding_id = w and name = 'Programme, MC & music'), 'Need to assign one for entertainment', 'Not started', 'Tich: DJ, liveband to be confirmed', 4),
    (w, 'Urgent – This Week', 'Book photographer & videographer (December is fully booked fast)', '2026-11-14', (select id from committees where wedding_id = w and name = 'Photo & video'), 'Naison Chigidi', 'In progress', 'Video & photography to be found: need to get someone running with this: Dzot, get 2 or 3 options. Kujeke photographer', 5),
    (w, 'Urgent – This Week', 'Book caterers', '2026-11-14', (select id from committees where wedding_id = w and name = 'Catering & cake'), 'Mr. Ngarande/Mvududu', 'In progress', 'Caterer needs to provide us quotation. Mvududu(Decor, chaffling dishes, 300 plates for her to confirm how many she has), Chakonda to be engaged as caterer. to get feedback 9 Nov 2026. we have gotten a volunteer to provide catering for the wedding. budget for catering to adjusted. add kaylights for kids.', 6),
    (w, 'Urgent – This Week', 'Finalize decor provider (for 350 chairs)', '2026-11-11', (select id from committees where wedding_id = w and name = 'Decor & seating'), 'Mai Mandebvu', 'In progress', null, 7),
    (w, 'Urgent – This Week', 'Finalise of deposits to be paid: decor, catering, venue, photographer, makeup,', '2026-11-18', (select id from committees where wedding_id = w and name = 'Finance'), 'Tatenda', 'In progress', 'to commit to making deposits to secure service providers', 8),
    (w, 'Urgent – This Week', '★ Book generator + standby generator', '2026-11-14', (select id from committees where wedding_id = w and name = 'Venue, power & water'), 'MK to handle.', 'Not started', 'need to buy 25 litres fuel. to confirm if its petrol or diesel', 9),
    (w, 'Urgent – This Week', '★ Book water bowser for 5,000 L & check tank capacity', '2026-11-14', (select id from committees where wedding_id = w and name = 'Venue, power & water'), null, 'Not started', 'Payment to be made for water', 10),
    (w, 'Urgent – This Week', 'Send digital invites / WhatsApp save-the-date with RSVP deadline', '2026-11-14', (select id from committees where wedding_id = w and name = 'Programme, MC & music'), null, 'In progress', null, 11),
    (w, 'Urgent – This Week', 'Choose bridal party & colour theme', '2026-11-14', (select id from committees where wedding_id = w and name = 'Bridal party & attire'), null, 'In progress', 'Colours sunset cruise', 12),
    (w, 'By 21 November', 'Wedding dress – buy / hire / confirm tailor can finish in time', '2026-11-21', (select id from committees where wedding_id = w and name = 'Bridal party & attire'), 'Tatenda', 'In progress', 'Gown being sown, and fittings to be ready by the 14th', 13),
    (w, 'By 21 November', 'Groom & groomsmen outfits', '2026-11-14', (select id from committees where wedding_id = w and name = 'Bridal party & attire'), 'Tatenda', 'In progress', 'Suit being sown, and to be finalised by the 14th for fittings.', 14),
    (w, 'By 21 November', 'Bridesmaids & minibrides outfits', '2026-11-21', (select id from committees where wedding_id = w and name = 'Bridal party & attire'), 'Ms', 'In progress', 'Deposit paid for dresses, shoes and makeup outstanding.  7 to 11 girls money to be paid on the 9th for them to start being sown. mini bride dresses coming from New zealand', 15),
    (w, 'By 21 November', 'Buy rings', '2026-11-21', (select id from committees where wedding_id = w and name = 'Bridal party & attire'), 'Tatenda', 'In progress', 'paid deposit, balance by mid month', 16),
    (w, 'By 21 November', 'Order cake', '2026-11-28', (select id from committees where wedding_id = w and name = 'Catering & cake'), 'tete Mukusha', 'In progress', '9 small & 3 small cakes baked already. 3 large to be baked 8 November, and we need to find team to pack favours of the cake. portia to finalise packing of the cake. mai nyaungwa to confirm if items for cake cutting are there', 17),
    (w, 'By 21 November', 'Book hair, makeup & nails', '2026-11-21', (select id from committees where wedding_id = w and name = 'Bridal party & attire'), 'Portia', 'In progress', 'Portia to work on providing update on make up. 4 have paid deposit so far', 18),
    (w, 'By 21 November', 'Book decor team & visit venue together', '2026-11-21', (select id from committees where wedding_id = w and name = 'Decor & seating'), null, 'Not started', null, 19),
    (w, 'By 21 November', 'Book bridal car & guest transport', '2026-11-21', (select id from committees where wedding_id = w and name = 'Transport'), 'mr matafi & mr musami', 'In progress', 'to get feedback on transport', 20),
    (w, 'By 21 November', '★ Arrange overflow parking with a neighbour (school / church / business)', '2026-11-21', (select id from committees where wedding_id = w and name = 'Security, parking & ushers'), null, 'Not started', null, 21),
    (w, 'By 21 November', '★ Plan second dressing area – only 1 changing room', '2026-11-21', (select id from committees where wedding_id = w and name = 'Bridal party & attire'), null, 'Not started', null, 22),
    (w, 'By 21 November', 'Organise pledges from family & friends', '2026-11-21', (select id from committees where wedding_id = w and name = 'Finance'), 'Finance team', 'In progress', null, 23),
    (w, 'By 28 November', 'RSVP deadline – chase anyone who hasn''t replied', '2026-11-28', (select id from committees where wedding_id = w and name = 'Programme, MC & music'), null, 'Not started', null, 24),
    (w, 'By 28 November', 'Draft menu & grocery list (Catering tab)', '2026-11-14', (select id from committees where wedding_id = w and name = 'Catering & cake'), 'Mr. Ngarande/Mvududu', 'In progress', 'mrs mvududu, to provide catering budget breakdown', 25),
    (w, 'By 28 November', 'Finance: gifts table and receipt book , and swipe machine', '2026-11-18', (select id from committees where wedding_id = w and name = 'Finance'), 'Tatenda', 'Not started', 'to confirm, if we can get zb swipe machine plus get receipt book', 26),
    (w, 'By 28 November', '★ Confirm cooking gas, burners & pots (no electricity in kitchen)', '2026-11-28', (select id from committees where wedding_id = w and name = 'Catering & cake'), null, 'Not started', null, 27),
    (w, 'By 28 November', '★ Test PA & media screens on generator power', '2026-11-28', (select id from committees where wedding_id = w and name = 'Programme, MC & music'), null, 'Not started', null, 28),
    (w, 'By 28 November', 'Plan order of service & programme', '2026-11-28', (select id from committees where wedding_id = w and name = 'Programme, MC & music'), null, 'Not started', null, 29),
    (w, 'By 28 November', 'Seating plan (couches for elders / VIPs)', '2026-11-28', (select id from committees where wedding_id = w and name = 'Decor & seating'), null, 'Not started', null, 30),
    (w, 'By 28 November', '★ Recruit 4–6 parking marshals', '2026-11-28', (select id from committees where wedding_id = w and name = 'Security, parking & ushers'), null, 'Not started', null, 31),
    (w, 'By 28 November', '★ Rain plan: gazebos/tents, umbrellas, mats at entrance (rainy season)', '2026-11-28', (select id from committees where wedding_id = w and name = 'Venue, power & water'), null, 'Not started', null, 32),
    (w, 'By 28 November', 'Buy non-perishables early (rice, oil, mealie meal, drinks) before festive price rises', '2026-11-28', (select id from committees where wedding_id = w and name = 'Catering & cake'), null, 'Not started', null, 33),
    (w, '2 Weeks Before', 'Final dress fitting', '2026-11-21', (select id from committees where wedding_id = w and name = 'Bridal party & attire'), null, 'Not started', null, 34),
    (w, '2 Weeks Before', 'Final guest count to caterer', '2026-11-21', (select id from committees where wedding_id = w and name = 'Catering & cake'), null, 'Not started', null, 35),
    (w, '2 Weeks Before', '★ Changing-room schedule (who dresses when)', '2026-11-21', (select id from committees where wedding_id = w and name = 'Bridal party & attire'), null, 'Not started', null, 36),
    (w, '2 Weeks Before', '★ Prepare slideshow / lyrics for media screens', '2026-11-21', (select id from committees where wedding_id = w and name = 'Programme, MC & music'), null, 'Not started', null, 37),
    (w, '2 Weeks Before', 'Pay balances due to vendors', '2026-11-21', (select id from committees where wedding_id = w and name = 'Finance'), null, 'Not started', null, 38),
    (w, '2 Weeks Before', 'Marriage licence / documents ready', '2026-11-21', (select id from committees where wedding_id = w and name = 'Coordination'), null, 'Not started', null, 39),
    (w, '2 Weeks Before', 'Buy wedding favours', '2026-11-21', (select id from committees where wedding_id = w and name = 'Bridal party & attire'), 'Tatenda', 'In progress', 'to be bought on shaine', 40),
    (w, '1 Week Before', 'Final meeting with all vendors – share Day Schedule', '2026-11-28', (select id from committees where wedding_id = w and name = 'Coordination'), null, 'Not started', null, 41),
    (w, '1 Week Before', '★ Confirm water bowser delivery for the day before', '2026-11-28', (select id from committees where wedding_id = w and name = 'Venue, power & water'), null, 'Not started', null, 42),
    (w, '1 Week Before', '★ Buy & store generator fuel (avoid festive fuel queues)', '2026-11-28', (select id from committees where wedding_id = w and name = 'Venue, power & water'), null, 'Not started', null, 43),
    (w, '1 Week Before', '★ Buy ice & cooler boxes (no fridge power)', '2026-11-28', (select id from committees where wedding_id = w and name = 'Catering & cake'), null, 'Not started', null, 44),
    (w, '1 Week Before', 'Buy fresh produce & meat', '2026-11-28', (select id from committees where wedding_id = w and name = 'Catering & cake'), null, 'Not started', null, 45),
    (w, '1 Week Before', 'Prepare emergency kit', '2026-11-28', (select id from committees where wedding_id = w and name = 'Coordination'), null, 'Not started', null, 46),
    (w, '1 Week Before', 'Rehearsal at church', '2026-11-28', (select id from committees where wedding_id = w and name = 'Programme, MC & music'), null, 'Not started', null, 47),
    (w, '1 Week Before', 'Pack bride & groom bags', '2026-11-28', (select id from committees where wedding_id = w and name = 'Bridal party & attire'), null, 'Not started', null, 48),
    (w, 'Day Before', '★ Water tank filled – check level', '2026-12-03', (select id from committees where wedding_id = w and name = 'Venue, power & water'), null, 'Not started', null, 49),
    (w, 'Day Before', '★ Generator delivered, test-run all equipment', '2026-12-03', (select id from committees where wedding_id = w and name = 'Venue, power & water'), null, 'Not started', null, 50),
    (w, 'Day Before', 'Decor setup', '2026-12-03', (select id from committees where wedding_id = w and name = 'Decor & seating'), null, 'Not started', null, 51),
    (w, 'Day Before', 'Bridal team dress house', '2026-12-04', (select id from committees where wedding_id = w and name = 'Bridal party & attire'), 'Portia', 'Not started', 'Bridal team to stay at Mai Mandebvu''s home', 52),
    (w, 'Day Before', 'Kitchen setup & food prep', '2026-12-03', (select id from committees where wedding_id = w and name = 'Catering & cake'), null, 'Not started', null, 53),
    (w, 'Day Before', '★ Put up parking & direction signs', '2026-12-03', (select id from committees where wedding_id = w and name = 'Security, parking & ushers'), null, 'Not started', null, 54),
    (w, 'Day Before', '★ Check weather forecast; set up rain covers', '2026-12-03', (select id from committees where wedding_id = w and name = 'Venue, power & water'), null, 'Not started', null, 55),
    (w, 'Day Before', 'Hand over rings & documents to best man / maid of honour', '2026-12-03', (select id from committees where wedding_id = w and name = 'Bridal party & attire'), null, 'Not started', null, 56),
    (w, 'Wedding Day', '★ Generator on 1 hr before guests arrive', '2026-12-05', (select id from committees where wedding_id = w and name = 'Venue, power & water'), null, 'Not started', null, 57),
    (w, 'Wedding Day', '★ Marshals at car park 1.5 hrs before start', '2026-12-05', (select id from committees where wedding_id = w and name = 'Security, parking & ushers'), 'Gwawawa', 'Not started', 'umyf to cater for security,  with Mr. Gwawawa to be put incharge of getting the team.', 58),
    (w, 'Wedding Day', 'Ushers to be identified and provided with chiffons', '2026-11-05', (select id from committees where wedding_id = w and name = 'Security, parking & ushers'), null, 'Not started', null, 59),
    (w, 'Wedding Day', 'Bride & bridesmaids in changing room per schedule', '2026-12-05', (select id from committees where wedding_id = w and name = 'Bridal party & attire'), null, 'Not started', null, 60),
    (w, 'Wedding Day', 'Enjoy the day!', '2026-12-05', (select id from committees where wedding_id = w and name = 'Coordination'), null, 'Not started', null, 61),
    (w, 'After', 'Return hired items (generator, chairs, pots, tents)', '2026-12-12', (select id from committees where wedding_id = w and name = 'Venue, power & water'), null, 'Not started', null, 62),
    (w, 'After', '★ Clean church auditorium & kitchen, hand back keys', '2026-12-12', (select id from committees where wedding_id = w and name = 'Venue, power & water'), null, 'Not started', null, 63),
    (w, 'After', 'Pay any outstanding balances', '2026-12-12', (select id from committees where wedding_id = w and name = 'Finance'), null, 'Not started', null, 64),
    (w, 'After', 'Send thank-you messages', '2026-12-12', (select id from committees where wedding_id = w and name = 'Coordination'), null, 'Not started', null, 65),
    (w, 'After', 'Collect photos & video', '2026-12-12', (select id from committees where wedding_id = w and name = 'Photo & video'), null, 'Not started', null, 66);

  insert into budget_lists (wedding_id, name, supplier, contact, notes, sort)
  values (w, 'Food – Christec quote', 'Christec Caterers', '0776 832 362',
          'Quote for 700 people. Printed total $2,101.00; the cordon bleu items add up to $91, not the printed $90, so the list totals $2,102. Spices money is paid to the caterer separately. Food only – labour / catering fee not included.', 0)
  returning id into food;

  insert into budget_items (wedding_id, list_id, category, item, detail, amount, sort) values
    (w, food, 'Main food items', 'Chicken', '75 birds', 450, 0),
    (w, food, 'Main food items', 'Beef', '80kg', 400, 1),
    (w, food, 'Main food items', 'Mealie meal', '40kg', 24, 2),
    (w, food, 'Main food items', 'Rice', '35kg Basmati', 77, 3),
    (w, food, 'Main food items', 'Potatoes', '6 pockets', 60, 4),
    (w, food, 'Main food items', 'Butternut', '6 pockets', 30, 5),
    (w, food, 'Main food items', 'Cooking oil', '24L', 36, 6),
    (w, food, 'Main food items', 'Green beans', null, 15, 7),
    (w, food, 'Main food items', 'Carrots', '2 buckets', 22, 8),
    (w, food, 'Main food items', 'Tomatoes', 'sandak', 15, 9),
    (w, food, 'Main food items', 'Cherry tomatoes, raisins, honey, watermelon', null, 20, 10),
    (w, food, 'Main food items', 'Onions', 'pocket', 8, 11),
    (w, food, 'Main food items', 'Red onion', 'kg', 5, 12),
    (w, food, 'Main food items', 'Peppers', null, 25, 13),
    (w, food, 'Main food items', 'Salt', '4kg', 4, 14),
    (w, food, 'Main food items', 'Tomato puree', '8 tins', 16, 15),
    (w, food, 'Main food items', 'Cabbage', '10 heads', 10, 16),
    (w, food, 'Main food items', 'Lettuce', '15 heads', 15, 17),
    (w, food, 'Main food items', 'Broccoli', '8 heads', 8, 18),
    (w, food, 'Main food items', 'Cauliflower', '8 heads', 8, 19),
    (w, food, 'Main food items', 'Beetroot', '10kg', 20, 20),
    (w, food, 'Main food items', 'Apples', '2kg', 6, 21),
    (w, food, 'Main food items', 'English cucumber', '15', 15, 22),
    (w, food, 'Main food items', 'Mayonnaise', '12 btls', 30, 23),
    (w, food, 'Main food items', 'Spices, sauces, soups, garnishes', null, 60, 24),
    (w, food, 'Main food items', 'Gas', '9kg', 15, 25),
    (w, food, 'Main food items', 'Boom dishwash', '6 x 750ml', 12, 26),
    (w, food, 'Main food items', 'Cooking gel', '5L', 15, 27),
    (w, food, 'Main food items', 'Firewood', null, 50, 28),
    (w, food, 'Refreshments', 'Drinks – Delta bottles', '30 crates', 240, 29),
    (w, food, 'Refreshments', 'High table juices', '12', 24, 30),
    (w, food, 'Refreshments', 'Water', '30 cases', 120, 31),
    (w, food, 'Refreshments', 'Ice', '10 blocks', 15, 32),
    (w, food, 'Refreshments', 'Ice cream', '30L', 60, 33),
    (w, food, 'Refreshments', 'Disposable spoons', '2 packs', 5, 34),
    (w, food, 'Breakfast for caterers', 'Bread', '2 loaves', 2, 35),
    (w, food, 'Breakfast for caterers', 'Milk', '2L', 3, 36),
    (w, food, 'Breakfast for caterers', 'Mazoe', '2L', 3.5, 37),
    (w, food, 'Breakfast for caterers', 'Tea bags', null, 2, 38),
    (w, food, 'Breakfast for caterers', 'Eggs', '2 dozen', 3, 39),
    (w, food, 'Breakfast for caterers', 'Sugar', '2kg', 2.5, 40),
    (w, food, 'Cordon bleu – high table (100 people)', 'Bread crumbs', null, 20, 41),
    (w, food, 'Cordon bleu – high table (100 people)', 'Chicken breast', '5kg', 25, 42),
    (w, food, 'Cordon bleu – high table (100 people)', 'Cheese', null, 24, 43),
    (w, food, 'Cordon bleu – high table (100 people)', 'Ham', null, 12, 44),
    (w, food, 'Cordon bleu – high table (100 people)', 'Flour', null, 2, 45),
    (w, food, 'Cordon bleu – high table (100 people)', 'Milk', '2L', 3, 46),
    (w, food, 'Cordon bleu – high table (100 people)', 'Cling wrap', null, 5, 47),
    (w, food, 'Logistics & disposables', 'Fuel for logistics', null, 30, 48),
    (w, food, 'Logistics & disposables', 'Disposable tumblers', null, 30, 49);

  raise notice 'Created wedding %', w;
end $$;
