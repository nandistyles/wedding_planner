-- Only needed if you already ran the first single-wedding file (supabase_setup.sql).
-- It removes those tables so 0001_init.sql can create the multi-wedding version.
-- WARNING: deletes any data in them.
drop table if exists updates, meetings, tasks, food_items, members, committees cascade;
drop function if exists public.is_member();
drop function if exists public.is_admin();
