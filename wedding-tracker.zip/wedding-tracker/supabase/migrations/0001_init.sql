-- =====================================================================
-- Wedding tracker – database schema (multi-wedding)
-- Run once in Supabase → SQL Editor → New query → Run.
--   1. tables   2. access helpers   3. row-level security
--   4. functions the app calls
-- Then run supabase/seed/0002_standard_plan.sql (the checklist template).
-- =====================================================================

-- ---------- 1. Tables ----------

-- People allowed to create new weddings (you, and any planner you work with).
create table app_admins (
  email      text primary key check (email = lower(email)),
  name       text,
  created_at timestamptz not null default now()
);

create table weddings (
  id            uuid primary key default gen_random_uuid(),
  couple        text not null,                 -- e.g. 'Mercy & Garikai'
  wedding_date  date not null,
  venue         text,
  venue_address text,
  guest_count   int,
  notes         text,
  status        text not null default 'active' check (status in ('active','archived')),
  created_by    text,
  created_at    timestamptz not null default now()
);

create table committees (
  id         bigint generated always as identity primary key,
  wedding_id uuid not null references weddings(id) on delete cascade,
  name       text not null,
  lead       text,
  sort       int not null default 0,
  unique (wedding_id, name)
);

-- Who can sign in to each wedding, and what they can do.
--   owner   – everything, including archiving the wedding and managing other owners
--   planner – manage people, committees and wedding details
--   member  – use checklist, meetings, updates and budget
create table wedding_members (
  id           bigint generated always as identity primary key,
  wedding_id   uuid not null references weddings(id) on delete cascade,
  email        text not null check (email = lower(email)),
  name         text,
  committee_id bigint references committees(id) on delete set null,
  role         text not null default 'member' check (role in ('owner','planner','member')),
  created_at   timestamptz not null default now(),
  unique (wedding_id, email)
);

create table meetings (
  id            bigint generated always as identity primary key,
  wedding_id    uuid not null references weddings(id) on delete cascade,
  meeting_date  date not null,
  start_time    text,
  place         text,
  chair         text,
  minutes_taker text,
  attendees     text,
  apologies     text,
  minutes       text,          -- decisions and general minutes
  minutes_final boolean not null default false,
  created_by    text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- Checklist tasks. Action points raised in a meeting are tasks with source_meeting_id set.
create table tasks (
  id                bigint generated always as identity primary key,
  wedding_id        uuid not null references weddings(id) on delete cascade,
  section           text,
  title             text not null,
  due_date          date,
  committee_id      bigint references committees(id) on delete set null,
  responsible       text,
  status            text not null default 'Not started' check (status in ('Not started','In progress','Done')),
  notes             text,
  sort              int not null default 0,
  source_meeting_id bigint references meetings(id) on delete set null,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  updated_by        text
);

-- Committee reports given at a meeting.
create table updates (
  id           bigint generated always as identity primary key,
  wedding_id   uuid not null references weddings(id) on delete cascade,
  meeting_id   bigint references meetings(id) on delete cascade,
  committee_id bigint references committees(id) on delete set null,
  task_id      bigint references tasks(id) on delete set null,
  done         text not null,
  next_steps   text,
  blockers     text,
  new_status   text check (new_status in ('Not started','In progress','Done')),
  author       text,
  created_at   timestamptz not null default now()
);

-- Budgets: a wedding can have several lists (food quote, decor quote, …).
create table budget_lists (
  id         bigint generated always as identity primary key,
  wedding_id uuid not null references weddings(id) on delete cascade,
  name       text not null,
  supplier   text,
  contact    text,
  notes      text,
  sort       int not null default 0
);

create table budget_items (
  id         bigint generated always as identity primary key,
  wedding_id uuid not null references weddings(id) on delete cascade,
  list_id    bigint not null references budget_lists(id) on delete cascade,
  category   text not null default 'General',
  item       text not null,
  detail     text,
  amount     numeric(12,2) not null default 0,
  bought     boolean not null default false,
  notes      text,
  sort       int not null default 0
);

-- The standard plan copied into every new wedding.
create table template_committees (
  id   bigint generated always as identity primary key,
  name text not null unique,
  sort int not null default 0
);

create table template_tasks (
  id             bigint generated always as identity primary key,
  title          text not null,
  days_before    int not null,         -- negative = after the wedding
  committee_name text,
  sort           int not null default 0
);

create index on committees (wedding_id);
create index on wedding_members (email);
create index on meetings (wedding_id, meeting_date);
create index on tasks (wedding_id, due_date);
create index on tasks (source_meeting_id);
create index on updates (wedding_id, meeting_id);
create index on budget_items (list_id);

-- ---------- 2. Access helpers ----------

create or replace function public.current_email() returns text
language sql stable as $$
  select lower(coalesce(auth.jwt() ->> 'email', ''));
$$;

create or replace function public.is_app_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from app_admins where email = current_email());
$$;

create or replace function public.wedding_role(wid uuid) returns text
language sql stable security definer set search_path = public as $$
  select role from wedding_members where wedding_id = wid and email = current_email() limit 1;
$$;

create or replace function public.is_wedding_member(wid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select wedding_role(wid) is not null;
$$;

create or replace function public.can_manage(wid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(wedding_role(wid) in ('owner','planner'), false);
$$;

-- Checklist heading for a template task, from how far before the wedding it falls.
create or replace function public.section_label(days int) returns text
language sql immutable as $$
  select case
    when days >= 90 then 'Three months or more before'
    when days >= 56 then 'Two months before'
    when days >= 28 then 'One month before'
    when days >= 14 then 'Two weeks before'
    when days >= 7  then 'One week before'
    when days >= 2  then 'Final week'
    when days = 1   then 'Day before'
    when days = 0   then 'Wedding day'
    else 'After the wedding'
  end;
$$;

-- ---------- 3. Row-level security ----------

alter table app_admins          enable row level security;
alter table weddings            enable row level security;
alter table committees          enable row level security;
alter table wedding_members     enable row level security;
alter table meetings            enable row level security;
alter table tasks               enable row level security;
alter table updates             enable row level security;
alter table budget_lists        enable row level security;
alter table budget_items        enable row level security;
alter table template_committees enable row level security;
alter table template_tasks      enable row level security;

create policy "see own admin row"    on app_admins for select to authenticated using (email = current_email() or is_app_admin());
create policy "admins add admins"    on app_admins for insert to authenticated with check (is_app_admin());
create policy "admins remove admins" on app_admins for delete to authenticated using (is_app_admin() and email <> current_email());

-- Weddings are created only through create_wedding() below.
create policy "members see wedding"   on weddings for select to authenticated using (is_wedding_member(id));
create policy "managers edit wedding" on weddings for update to authenticated using (can_manage(id)) with check (can_manage(id));
create policy "owners delete wedding" on weddings for delete to authenticated using (wedding_role(id) = 'owner');

create policy "members see committees"     on committees for select to authenticated using (is_wedding_member(wedding_id));
create policy "managers add committees"    on committees for insert to authenticated with check (can_manage(wedding_id));
create policy "managers edit committees"   on committees for update to authenticated using (can_manage(wedding_id)) with check (can_manage(wedding_id));
create policy "managers delete committees" on committees for delete to authenticated using (can_manage(wedding_id));

-- Planners manage the team; only an owner can add, change or remove an owner. Nobody can remove themselves.
create policy "members see team" on wedding_members for select to authenticated using (is_wedding_member(wedding_id));
create policy "managers add people" on wedding_members for insert to authenticated
  with check (can_manage(wedding_id) and (role <> 'owner' or wedding_role(wedding_id) = 'owner'));
create policy "managers edit people" on wedding_members for update to authenticated
  using (can_manage(wedding_id) and (role <> 'owner' or wedding_role(wedding_id) = 'owner'))
  with check (can_manage(wedding_id) and (role <> 'owner' or wedding_role(wedding_id) = 'owner'));
create policy "managers remove people" on wedding_members for delete to authenticated
  using (can_manage(wedding_id) and (role <> 'owner' or wedding_role(wedding_id) = 'owner') and email <> current_email());

-- Everyday working tables: any team member can read and write; deleting a whole meeting needs a planner.
create policy "members read meetings"    on meetings for select to authenticated using (is_wedding_member(wedding_id));
create policy "members add meetings"     on meetings for insert to authenticated with check (is_wedding_member(wedding_id));
create policy "members edit meetings"    on meetings for update to authenticated using (is_wedding_member(wedding_id)) with check (is_wedding_member(wedding_id));
create policy "managers delete meetings" on meetings for delete to authenticated using (can_manage(wedding_id));

create policy "members use tasks"        on tasks        for all to authenticated using (is_wedding_member(wedding_id)) with check (is_wedding_member(wedding_id));
create policy "members use updates"      on updates      for all to authenticated using (is_wedding_member(wedding_id)) with check (is_wedding_member(wedding_id));
create policy "members use budget lists" on budget_lists for all to authenticated using (is_wedding_member(wedding_id)) with check (is_wedding_member(wedding_id));
create policy "members use budget items" on budget_items for all to authenticated using (is_wedding_member(wedding_id)) with check (is_wedding_member(wedding_id));

create policy "signed in reads committee template" on template_committees for select to authenticated using (true);
create policy "admins edit committee template"     on template_committees for all    to authenticated using (is_app_admin()) with check (is_app_admin());
create policy "signed in reads task template"      on template_tasks      for select to authenticated using (true);
create policy "admins edit task template"          on template_tasks      for all    to authenticated using (is_app_admin()) with check (is_app_admin());

-- ---------- 4. Functions the app calls ----------

-- Create a wedding, make the caller its owner, and (optionally) copy in the standard plan.
-- Template tasks whose date has already passed go under "Catch up first", due within a week.
create or replace function public.create_wedding(
  p_couple text, p_date date, p_venue text default null, p_venue_address text default null,
  p_guest_count int default null, p_owner_name text default null, p_use_template boolean default true
) returns uuid
language plpgsql security definer set search_path = public as $$
declare
  w  uuid;
  me text := current_email();
begin
  if not is_app_admin() then
    raise exception 'Only app admins can create weddings. Add your email to the app_admins table first.';
  end if;
  if coalesce(trim(p_couple), '') = '' or p_date is null then
    raise exception 'Couple names and wedding date are required.';
  end if;

  insert into weddings (couple, wedding_date, venue, venue_address, guest_count, created_by)
  values (trim(p_couple), p_date, nullif(trim(p_venue), ''), nullif(trim(p_venue_address), ''), p_guest_count, me)
  returning id into w;

  if p_use_template then
    insert into committees (wedding_id, name, sort)
      select w, name, sort from template_committees;

    insert into tasks (wedding_id, section, title, due_date, committee_id, sort)
      select w,
             case when p_date - t.days_before < current_date then 'Catch up first' else section_label(t.days_before) end,
             t.title,
             case when p_date - t.days_before < current_date then least(current_date + 7, p_date) else p_date - t.days_before end,
             c.id,
             t.sort
      from template_tasks t
      left join committees c on c.wedding_id = w and c.name = t.committee_name;
  end if;

  if not exists (select 1 from committees where wedding_id = w and name = 'Coordination') then
    insert into committees (wedding_id, name, sort) values (w, 'Coordination', 0);
  end if;

  insert into wedding_members (wedding_id, email, name, role, committee_id)
  values (w, me, coalesce(nullif(trim(p_owner_name), ''), me), 'owner',
          (select id from committees where wedding_id = w and name = 'Coordination'));

  return w;
end;
$$;

-- Replace the standard plan with this wedding's committees and dated checklist
-- (meeting action points are left out). Use it once a wedding's plan has been refined.
create or replace function public.save_wedding_as_template(p_wedding uuid) returns int
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if not (is_app_admin() and is_wedding_member(p_wedding)) then
    raise exception 'Only an app admin on this wedding can update the standard plan.';
  end if;

  delete from template_tasks where true;
  delete from template_committees where true;

  insert into template_committees (name, sort)
    select name, sort from committees where wedding_id = p_wedding;

  insert into template_tasks (title, days_before, committee_name, sort)
    select t.title, w.wedding_date - t.due_date, c.name, row_number() over (order by t.due_date, t.sort)
    from tasks t
    join weddings w on w.id = t.wedding_id
    left join committees c on c.id = t.committee_id
    where t.wedding_id = p_wedding and t.source_meeting_id is null and t.due_date is not null;

  get diagnostics n = row_count;
  return n;
end;
$$;

revoke execute on function public.create_wedding(text, date, text, text, int, text, boolean) from anon, public;
revoke execute on function public.save_wedding_as_template(uuid) from anon, public;
grant  execute on function public.create_wedding(text, date, text, text, int, text, boolean) to authenticated;
grant  execute on function public.save_wedding_as_template(uuid) to authenticated;
